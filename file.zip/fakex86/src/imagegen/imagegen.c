#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
     FILE *image;
     char blank[1048576];
     unsigned long i, size;
     
     printf("Fake86 hard drive image generation tool v1.0 (c)2011 Mike Chambers\n\n");
     
     if (argc<3) {
        printf("Usage syntax:\n");
        printf("    imagegen imagefile size\n\n");
        printf("imagefile denotes the filename of the new disk image to create.\n");
        printf("size denotes the size in megabytes that it should be.\n");
        return(1);
     }
     
     size = atoi(argv[2]);
     if ((size>503) || !size) {
        printf("Invalid size specified! Valid range is 1 to 503 MB.\n");
        return(1);
     }
     
     image = fopen(argv[1], "wb");
     if (image==NULL) {
        printf("Unable to create new file: %s\n", argv[1]);
        return(1);
     }
     
     printf("Please wait, generating new image...\n");
     
     for (i=0; i<size; i++) {
         fwrite(&blank[0], 1048576, 1, image);
         printf("\rWriting to file: %u MB", i);
     }
     printf(" complete.\n");
     return(0);
}
