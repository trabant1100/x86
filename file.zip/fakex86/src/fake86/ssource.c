/* ssource.c - part of the Fake86 8086 PC emulator
   This file contains the code to simulate the
   Disney Sound Source's 16-byte FIFO buffer. */

#include "common.h"

uint8_t ssourcebuf[16], ssourceptr = 0;
extern int32_t ssourcecursample;

uint8_t getssourcebyte() {
        uint8_t retbyte, rotatefifo;
        if (ssourceptr==0) return(0);
        retbyte = ssourcebuf[0];
        for (rotatefifo=1; rotatefifo<16; rotatefifo++)
            ssourcebuf[rotatefifo-1] = ssourcebuf[rotatefifo];
        ssourceptr--;
        portram[0x379] = 0;
        return(retbyte);
}

void putssourcebyte(uint8_t value) {
     if (ssourceptr==16) return;
     ssourcebuf[ssourceptr++] = value;
     if (ssourceptr==16) portram[0x379] = 0x40;
}

uint8_t ssourcefull() {
        if (ssourceptr==16) return(1);
           else return(0);
}
