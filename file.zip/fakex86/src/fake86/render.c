#include "common.h"

void draw () {
    uint32_t planemode, vgapage, color, chary, charx, vidptr, divx, divy, curchar, curpixel, usepal, intensity, blockw, curheight, x1, y1;
    int32_t ofs, maxptr, *bufp;
    if (SDL_MUSTLOCK(screen)) 
      if (SDL_LockSurface(screen) < 0) 
        return;
        maxptr = screen->w*screen->h - 1;
    switch (vidmode) {
        case 0:
        case 1:
        case 2: //text modes
        case 3:
             case 7:
                  case 0x82:
            for (y=0; y<400; y++)
                for (x=0; x<640; x++) {
                    if (cols==80) { charx = x/8; divx = 1; }
                        else { charx = x/16; divx = 2; }
                    if (portram[0x3D8]==9) {
                        chary = y/4;
                        vidptr = videobase + chary*cols*2 + charx*2;
                        curchar = RAM[vidptr];
                        color = fontcga[curchar*128 + (y%4)*8 + ((x/divx)%8)];
                    } else {
                        chary = y/16;
                        vidptr = videobase + chary*cols*2 + charx*2;
                        curchar = RAM[vidptr];
                        color = fontcga[curchar*128 + (y%16)*8 + ((x/divx)%8)];
                    }
                    if (vidcolor) {
                        if (!color) if (portram[0x3D8]&128) color = palettecga[(RAM[vidptr+1]/16)&7];
                                           else color = palettecga[RAM[vidptr+1]/16]; //high intensity background
                            else color = palettecga[RAM[vidptr+1]&15];
                    } else {
                        if ((RAM[vidptr+1] & 0x70)) {
                            if (!color) color = palettecga[7];
                                else color = palettecga[0];
                        } else {
                            if (!color) color = palettecga[0];
                                else color = palettecga[7];
                        }
                    }
                    ofs = y*screen->w + x;
                    if ((ofs >= 0) && (ofs <= maxptr))
                       ((uint32_t *)screen->pixels)[ofs] = SDL_MapRGB(screen->format, color&255, (color>>8)&255, color>>16);
                }
            break;
	case 4: case 5:
		usepal = (portram[0x3D9]>>5) & 1;
		intensity = ((portram[0x3D9]>>4) & 1) << 3;
		for (y=0; y<400; y++) {
			port3da = port3da & 0xFE; //mask out horiz retrace bit
    		for (x=0; x<640; x++) {
    			if (x==550) port3da = port3da | 1; //toggle horiz retrace bit on
	    		charx = x>>1;
    			chary = y>>1;
  				vidptr = videobase + ((chary>>1) * 80) + ((chary & 1) * 8192) + (charx >> 2);
    			curpixel = RAM[vidptr];
    			switch (charx & 3) {
    				case 3: curpixel = curpixel & 3; break;
    				case 2: curpixel = (curpixel>>2) & 3; break;
    				case 1: curpixel = (curpixel>>4) & 3; break;
    				case 0: curpixel = (curpixel>>6) & 3; break;
    			}
  				//pixel = video->pixels + y * video->pitch + x * len( integer )
    			if (vidmode==4) {
    				curpixel = curpixel * 2 + usepal + intensity;
    				if (curpixel == (usepal + intensity))  curpixel = cgabg;
    				color = palettecga[curpixel];
                    ofs = y*screen->w + x;
                    if ((ofs >= 0) && (ofs <= maxptr))
                       ((uint32_t *)screen->pixels)[ofs] = SDL_MapRGB(screen->format, color&255, (color>>8)&255, color>>16);
    			} else {
    				curpixel = curpixel * 63;
    				color = palettecga[curpixel];
                    ofs = y*screen->w + x;
                    if ((ofs >= 0) && (ofs <= maxptr))
                       ((uint32_t *)screen->pixels)[ofs] = SDL_MapRGB(screen->format, color&255, (color>>8)&255, color>>16);
                }
    		}
		}
		break;
	case 6:
	for (y=0; y<400; y++) {
		port3da = port3da & 0xFE; //mask out horiz retrace bit
    	for (x=0; x<640; x++) {
    			if (x==550) port3da = port3da | 1; //toggle horiz retrace bit on
	    		charx = x;
    			chary = y>>1;
  				vidptr = videobase + ((chary>>1) * 80) + ((chary&1) * 8192) + (charx>>3);
    			curpixel = (RAM[vidptr]>>(7-(charx&7)))&1;
    				color = palettecga[curpixel*15];
                    ofs = y*screen->w + x;
                    if ((ofs >= 0) && (ofs <= maxptr))
                       ((uint32_t *)screen->pixels)[ofs] = SDL_MapRGB(screen->format, color&255, (color>>8)&255, color>>16);
    	}
     }
     break;
     case 127:
	for (y=0; y<348; y++) {
		port3da = port3da & 0xFE; //mask out horiz retrace bit
    	for (x=0; x<720; x++) {
    			if (x==550) port3da = port3da | 1; //toggle horiz retrace bit on
	    		charx = x;
    			chary = y>>1;
  				vidptr = videobase + ((y & 3) << 13) + (y >> 2)*90 + (x >> 3); //((chary>>1) * 80) + ((chary&1) * 8192) + (charx>>3);
    			curpixel = (RAM[vidptr]>>(7-(charx&7)))&1;
    				if (curpixel) color = 0xFFFFFF; else color = 0;
                    ofs = y*screen->w + x;
                    if ((ofs >= 0) && (ofs <= maxptr))
                       ((uint32_t *)screen->pixels)[ofs] = SDL_MapRGB(screen->format, color&255, (color>>8)&255, color>>16);
    	}
     }
     break;
        case 0x8: //160x200 16-color (PCjr)
            for (y=0; y<400; y++)
                for (x=0; x<640; x++) {
                    vidptr = 0xB8000 + (y>>2)*80 + (x>>3) + ((y>>1)&1)*8192; //(((y/2)*160) / 8000) * 8192 + (x/4);
                    if (((x>>1)&1)==0) color = palettecga[RAM[vidptr] >> 4];
                       else color = palettecga[RAM[vidptr] & 15];
                    ofs = y*screen->w + x;
                    if ((ofs >= 0) && (ofs <= maxptr))
                       ((uint32_t *)screen->pixels)[ofs] = SDL_MapRGB(screen->format, color&255, (color>>8)&255, color>>16);
                }
        break;
        case 0x9: //320x200 16-color (Tandy/PCjr)
            for (y=0; y<400; y++)
                for (x=0; x<640; x++) {
                    vidptr = 0xB8000 + (y>>3)*160 + (x>>2) + ((y>>1)&3)*8192; //(((y/2)*160) / 8000) * 8192 + (x/4);
                    if (((x>>1)&1)==0) color = palettecga[RAM[vidptr] >> 4];
                       else color = palettecga[RAM[vidptr] & 15];
                    ofs = y*screen->w + x;
                    if ((ofs >= 0) && (ofs <= maxptr))
                       ((uint32_t *)screen->pixels)[ofs] = SDL_MapRGB(screen->format, color&255, (color>>8)&255, color>>16);
                }
        break;
        case 0xD:
            for (y=0; y<400; y++)
                for (x=0; x<640; x++) {
                    vidptr = (y/2)*40 + (x/16);
                    //vidptr = vidptr/4; //((x/2) % 4)*32768;
                    color = palettevga[VRAM[vidptr]];
                    /*color = VRAM[vidptr]>>(7-((x/2)%8));
                    color += VRAM[vidptr+32768];
                    color += VRAM[vidptr+32768*2];
                    color += VRAM[vidptr+32768*3];
                    color += VRAM[vidptr+32768*4];
                    color += VRAM[vidptr+32768*5];
                    color += VRAM[vidptr+32768*6];
                    color += VRAM[vidptr+32768*7];*/
                    //if ((x/2)%2) color = palettevga[color & 15];
                       //else color = palettevga[(color>>4) & 15];
                    ofs = y*screen->w + x;
                    if ((ofs >= 0) && (ofs <= maxptr))
                       ((uint32_t *)screen->pixels)[ofs] = SDL_MapRGB(screen->format, color&255, (color>>8)&255, color>>16);
                }
            break;
        case 0x12:
             vgapage = ((uint32_t)VGA_CRTC[0xC]<<8) + (uint32_t)VGA_CRTC[0xD];
            for (y=0; y<480; y++)
                for (x=0; x<640; x++) {
                    vidptr = y*80 + (x/8);
                    color = (VRAM[vidptr] >> (7-(x%8)))&1;
                    color += ((VRAM[vidptr+0x10000] >> (7-(x%8)))&1)*2;
                    color += ((VRAM[vidptr+0x20000] >> (7-(x%8)))&1)*4;
                    color += ((VRAM[vidptr+0x30000] >> (7-(x%8)))&1)*8;
                    color = palettevga[color];
                    ofs = y*screen->w + x;
                    if ((ofs >= 0) && (ofs <= maxptr))
                       ((uint32_t *)screen->pixels)[ofs] = SDL_MapRGB(screen->format, color&255, (color>>8)&255, color>>16);
                }
            break;
        case 0x13:
             if (VGA_SC[4] & 6) planemode = 1; else planemode = 0;
             vgapage = ((uint32_t)VGA_CRTC[0xC]<<8) + (uint32_t)VGA_CRTC[0xD];
            for (y=0; y<400; y++)
                for (x=0; x<640; x++) {
                    if (!planemode) color = palettevga[RAM[videobase + (y/2)*320 + (x/2)]];
                       else {
                             vidptr = (y/2)*320 + x/2;
                             vidptr = vidptr/4 + ((x/2) % 4)*0x10000;
                             vidptr = vidptr + vgapage - (VGA_ATTR[0x13] & 15);
                             color = palettevga[VRAM[vidptr]];
                        }
                    ofs = y*screen->w + x;
                    if ((ofs >= 0) && (ofs <= maxptr))
                       ((uint32_t *)screen->pixels)[ofs] = SDL_MapRGB(screen->format, color&255, (color>>8)&255, color>>16);
                }
            }

            if (vidgfxmode==0) {
            	if (cursorvisible) {
             		curheight = 2;
               		if (cols==80) blockw = 8; else blockw = 16;
                 		x1 = cursx * blockw;
                   		y1 = cursy * 8 + 8 - curheight;
                     	for (y=y1*2; y<=y1*2+curheight-1; y++)
                     		for (x=x1; x<=x1+blockw-1; x++) {
                       			color = palettecga[RAM[videobase+cursy*cols*2+cursx*2+1]&15];
                                ofs = y*screen->w + x;
                                if ((ofs >= 0) && (ofs <= maxptr))
                                   ((uint32_t *)screen->pixels)[ofs] = SDL_MapRGB(screen->format, color&255, (color>>8)&255, color>>16);
                          }
                 }
             }

    if (SDL_MUSTLOCK(screen)) 
      SDL_UnlockSurface(screen);
    SDL_UpdateRect(screen, 0, 0, screen->w, screen->h);
}
