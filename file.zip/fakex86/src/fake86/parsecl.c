#include "common.h"
#ifndef _WIN32
        #define strcmpi strcasecmp
#endif

struct struct_drive {
    FILE *diskfile;
    uint32_t filesize;
    uint16_t cyls;
    uint16_t sects;
    uint16_t heads;
    uint8_t inserted;
    char *filename;
} extern disk[256];

void parsecl(int argc, char *argv[]) {
     int i, abort = 0;

     if (argc<2) {
        print("Fake86 requires some command line parameters to run.\nValid options:\n");
        
        print("  -fd0 filename    Specify a floppy disk image file to use as floppy 0.\n");
        print("  -fd1 filename    Specify a floppy disk image file to use as floppy 1.\n");
        print("  -hd0 filename    Specify a hard disk image file to use as hard drive 0.\n");
        print("  -hd1 filename    Specify a hard disk image file to use as hard drive 1.\n");
        print("  -boot #          Specify which BIOS drive ID should be the boot device in #.\n");
        print("                   Examples: -boot 0 will boot from floppy 0.\n");
        print("                             -boot 1 will boot from floppy 1.\n");
        print("                             -boot 128 will boot from hard drive 0.\n");
        print("                             -boot 129 will boot from hard drive 1.\n");
        print("                             -boot rom will boot to ROM BASIC if available.\n");
        print("                   Default boot device is hard drive 0, if it exists.\n");
        print("                   Otherwise, the default is floppy 0.\n");
        #if defined(NETWORKING_ENABLED)
            #if defined(_WIN32)
                print("  -net #           Enable ethernet emulation via winpcap, where # is the\n");
            #else
                print("  -net #           Enable ethernet emulation via libpcap, where # is the\n");
            #endif
            print("                   numeric ID of your host's network interface to bridge.\n");
	    print("                   To get a list of possible interfaces, use -net list\n");
	#endif
        print("  -nosound         Disable audio emulation and output.\n");
        print("  -fullscreen      Start Fake86 in fullscreen mode.\n");
        print("  -verbose         Verbose mode. Operation details will be written to stdout.\n");
        exit(1);
     }
     
     bootdrive = 254;
     textbase = 0xB8000;
     ethif = 254;
     doaudio = 1;
     usefullscreen = 0;
     biosfile = "xtbios.bin";
     for (i=1; i<argc; i++) {
         if (strcmpi(argv[i], "-fd0")==0) {
            i++;
            if (insertdisk(0, argv[i])) {
               sprintf(msg, "ERROR: Unable to open image file %s\n", argv[i]); print(msg);
            }
         } else if (strcmpi(argv[i], "-fd1")==0) {
            i++;
            if (insertdisk(1, argv[i])) {
               sprintf(msg, "ERROR: Unable to open image file %s\n", argv[i]); print(msg);
            }
         } else if (strcmpi(argv[i], "-hd0")==0) {
            i++;
            if (insertdisk(0x80, argv[i])) {
               sprintf(msg, "ERROR: Unable to open image file %s\n", argv[i]); print(msg);
            }
         } else if (strcmpi(argv[i], "-hd1")==0) {
            i++;
            if (insertdisk(0x81, argv[i])) {
               sprintf(msg, "ERROR: Unable to open image file %s\n", argv[i]); print(msg);
            }
         } else if (strcmpi(argv[i], "-net")==0) {
            i++;
            if (strcmpi(argv[i], "list")==0) ethif = 255;
               else ethif = atoi(argv[i]);
         } else if (strcmpi(argv[i], "-boot")==0) {
            i++;
            if (strcmpi(argv[i], "rom")==0) bootdrive = 255;
               else bootdrive = atoi(argv[i]);
         } else if (strcmpi(argv[i], "-bios")==0) {
                i++;
                biosfile = argv[i];
         } else if (strcmpi(argv[i], "-verbose")==0) verbose = 1;
           else if (strcmpi(argv[i], "-nosound")==0) doaudio = 0;
           else if (strcmpi(argv[i], "-fullscreen")==0) usefullscreen = SDL_FULLSCREEN;
           else {
                sprintf(msg, "Unrecognized parameter: %s\n", argv[i]); print(msg);
                exit(1);
         }
     }
     
     if (bootdrive==254) {
        if (disk[0x80].inserted) bootdrive = 0x80;
           else bootdrive = 0;
     }
}
