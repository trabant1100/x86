#include <stdint.h>
#include <SDL/SDL.h>
#include "global.h"

#if defined(_WIN32)
#include <windows.h>
#else
#include <time.h>
#endif
uint64_t curtimer, lasttimer, timerfreq;

char *biosfile = NULL;
uint8_t byteregtable[8] = { regal, regcl, regdl, regbl, regah, regch, regdh, regbh };

uint8_t RAM[0x1FFFFF], readonly[0xFFFFF], parity[0xFF];
char *oplist[0xFF];
char used_opcodes[0xFF];

uint16_t segregs[4];
uint8_t opcode, segoverride, reptype, bootdrive = 0, hdcount = 0;
uint16_t savecs, saveip, ip, useseg, oldsp;
uint8_t tempcf, oldcf, cf, pf, af, zf, sf, tf, ifl, df, of, nt, iopl, mode, reg, rm, msw = 0;
uint16_t oper1, oper2, res16, disp16, temp16, dummy, stacksize, frametemp;
uint8_t oper1b, oper2b, res8, disp8, temp8, nestlev, addrbyte;
uint32_t temp1, temp2, temp3, temp4, temp5, temp32, tempaddr32, ea;
int32_t result;
uint64_t totalexec, ticksgap = 100000, lasttick = 0;
uint32_t ips[10] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

uint16_t portram[0xFFFF];
uint8_t VRAM[262144], vidmode, cgabg, blankattr, vidgfxmode, vidcolor;
uint16_t cursx, cursy, cols, rows, vgapage, cursorposition, cursorvisible;
uint8_t updatedscreen, clocksafe, port3da, port6, portout16;
uint16_t VGA_SC[0xFF], VGA_CRTC[0xFF], VGA_ATTR[0xFF], VGA_GC[0xFF];
uint32_t videobase, textbase, x, y;
uint8_t fontcga[32768];
uint32_t palettecga[16], palettevga[256];

uint8_t running, debugmode, showcsip, verbose, mouseemu;

SDL_Surface *screen = NULL;
#if defined(_WIN32)
HANDLE screenmutex;
HANDLE pktmutex;
#define MutexLock(mutex) WaitForSingleObject(mutex,INFINITE)
#define MutexUnlock(mutex) ReleaseMutex(mutex)
#else
pthread_mutex_t screenmutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t pktmutex = PTHREAD_MUTEX_INITIALIZER;
#define MutexLock(mutex) pthread_mutex_lock(&mutex)
#define MutexUnlock(mutex) pthread_mutex_unlock(&mutex)
#endif

union _bytewordregs_ {
	uint16_t wordregs[8];
	uint8_t byteregs[8];
} regs;

uint8_t ethif;

char *bootimage;

extern SDL_AudioSpec wanted;
extern uint8_t buf[2][44100];
extern uint32_t bufpos;
FILE *audfile, *vidfile;

uint32_t speakercountdown, latch42, pit0latch, pit0command, pit0divisor, doclocktick, timerack;
int32_t accum;
int usefullscreen = 0, doaudio;

uint64_t speakerfreq, fullstep, halfstep, curstep, lastspeakertimer, lastssourcetimer, adlibstep[9];
uint8_t cursample, curchan;
uint64_t lasttimercheck, lastcurstimer, lastspeakertimer;

#define genspeaker() {\
	if ((curtimer - lastspeakertimer) >= (timerfreq/wanted.freq)) {\
		if (!speakercountdown) speakercountdown = 1;\
		speakerfreq = 1193180/speakercountdown;\
		if ((portram[0x61]&3)!=0) {\
			if (curstep<halfstep) cursample = 180; else cursample = 118;\
			curstep++; if (curstep==fullstep) curstep = 0;\
		} else cursample = 128;\
		buf[0][bufpos++] = cursample;\
		if (bufpos==wanted.samples) {\
			memcpy(&buf[1][0], &buf[0][0], wanted.samples);\
			bufpos = 0;\
		}\
		lastspeakertimer = curtimer;\
	}\
}


