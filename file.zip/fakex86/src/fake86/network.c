#include "common.h"
#if defined(NETWORKING_ENABLED)

struct netstruct {
       uint8_t enabled;
       uint8_t canrecv;
       uint16_t pktlen;
} net;

void nethandler() {
     uint32_t i;
     if (ethif==254) return;
     switch (regs.byteregs[regah]) { //function number
            case 0x00: //enable packet reception
                 net.enabled = 1;
                 net.canrecv = 1;
                 return;
            case 0x01: //send packet of CX at DS:SI
                 if (verbose) { sprintf(msg, "Sending packet of %u bytes.\n", regs.wordregs[regcx]); print(msg); }
                 sendpkt(&RAM[((uint32_t)segregs[regds] << 4) + (uint32_t)regs.wordregs[regsi]], regs.wordregs[regcx]);
                 return;
            case 0x02: //return packet info (packet buffer in DS:SI, length in CX)
                 segregs[regds] = 0xD000;
                 regs.wordregs[regsi] = 0x0000;
                 regs.wordregs[regcx] = net.pktlen;
                 /*for (i=0; i<net.pktlen; i++) {
                     sprintf(msg, "%02X ", RAM[((uint32_t)segregs[regds] << 4) + (uint32_t)regs.wordregs[regsi] + i]);
                     print(msg);
                 } print("\n\n");*/
                 return;
            case 0x03: //copy packet to final destination (given in ES:DI)
                 /*for (i=0; i<net.pktlen; i++) { //DEBUG TOOL: dump existing CX count bytes at ES:DI
                     sprintf(msg, "%c", RAM[((uint32_t)segregs[reges] << 4) + (uint32_t)regs.wordregs[regdi] + i]);
                     print(msg);
                 }*/
                 memcpy(&RAM[((uint32_t)segregs[reges] << 4) + (uint32_t)regs.wordregs[regdi]], &RAM[0xD0000], net.pktlen);
                 return;
            case 0x04: //disable packets
                 net.enabled = 0;
                 net.canrecv = 0;
                 return;
            case 0x05: //DEBUG: dump packet (DS:SI) of CX bytes to stdout
                 for (i=0; i<regs.wordregs[regcx]; i++) {
                     sprintf(msg, "%c", RAM[((uint32_t)segregs[regds] << 4) + (uint32_t)regs.wordregs[regsi] + i]); print(msg);
                 }
                 return;
            case 0x06: //DEBUG: print milestone string
                 //print("PACKET DRIVER MILESTONE REACHED\n");
                 return;
     }
}
#endif
