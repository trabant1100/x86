#include "common.h"

#if defined(_WIN32)
uint32_t dayticks() {
         SYSTEMTIME tmptime;
         uint32_t tmpticks;

         GetLocalTime(&tmptime);
         
         //change hours/minutes/seconds into just the current second of the day
         tmpticks = ((uint32_t)tmptime.wHour * 60 * 60) + ((uint32_t)tmptime.wMinute * 60) + ((uint32_t)tmptime.wSecond);
         //then convert it to milliseconds
         tmpticks = (tmpticks * 1000) + (uint32_t)tmptime.wMilliseconds;
         //then change measurement to 18.2 ticks/sec
         tmpticks = (uint32_t)((float)tmpticks / (1000.0 / 18.20648193359375));
         return(tmpticks);
}
#else
struct timeval tv;
uint32_t dayticks() {
         gettimeofday(&tv, NULL);
         tv.tv_usec /= 1000; //gettimeofday puts microseconds here, we want milliseconds
         return((uint32_t)((float)(tv.tv_usec % 86400000) / (1000.0 / 18.20648193359375)));
}
#endif
