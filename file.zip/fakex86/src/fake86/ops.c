#include "common.h"

extern void flag_adc8(uint8_t v1, uint8_t v2, uint8_t v3);
extern void flag_adc16(uint16_t v1, uint16_t v2, uint8_t v3);
extern void flag_add8(uint8_t v1, uint8_t v2);
extern void flag_add16(uint16_t v1, uint16_t v2);
extern void flag_and8(uint8_t v1, uint8_t v2);
extern void flag_and16(uint16_t v1, uint16_t v2);
extern void flag_or8(uint8_t v1, uint8_t v2);
extern void flag_or16(uint16_t v1, uint16_t v2);
extern void flag_xor8(uint8_t v1, uint8_t v2);
extern void flag_xor16(uint16_t v1, uint16_t v2);
extern void flag_sub8(uint8_t v1, uint8_t v2);
extern void flag_sub16(uint16_t v1, uint16_t v2);
extern void flag_sbb8(uint8_t v1, uint8_t v2, uint8_t v3);
extern void flag_sbb16(uint16_t v1, uint16_t v2, uint16_t v3);
extern void flag_log8(uint8_t v1);
extern void flag_log16(uint16_t v1);

inline void op_adc8() {
    res8 = oper1b + oper2b + cf;
    flag_adc8(oper1b, oper2b, cf);
}

inline void op_adc16() {
    res16 = oper1 + oper2 + cf;
    flag_adc16(oper1, oper2, cf);
}

inline void op_add8() {
    res8 = oper1b + oper2b;
    flag_add8(oper1b, oper2b);
}

inline void op_add16() {
    res16 = oper1 + oper2;
    flag_add16(oper1, oper2);
}

inline void op_and8() {
    res8 = oper1b & oper2b;
    flag_log8(res8);
}

inline void op_and16() {
    res16 = oper1 & oper2;
    flag_log16(res16);
}

inline void op_or8() {
    res8 = oper1b | oper2b;
    flag_log8(res8);
}

inline void op_or16() {
    res16 = oper1 | oper2;
    flag_log16(res16);
}

inline void op_xor8() {
    res8 = oper1b ^ oper2b;
    flag_log8(res8);
}

inline void op_xor16() {
    res16 = oper1 ^ oper2;
    flag_log16(res16);
}

inline void op_sub8() {
    res8 = oper1b - oper2b;
    flag_sub8(oper1b, oper2b);
}

inline void op_sub16() {
    res16 = oper1 - oper2;
    flag_sub16(oper1, oper2);
}

inline void op_sbb8() {
    res8 = oper1b - (oper2b + cf);
    flag_sbb8(oper1b, oper2b, cf);
}

inline void op_sbb16() {
    res16 = oper1 - (oper2 + cf);
    flag_sbb16(oper1, oper2, cf);
}
