//#define CONSOLE
//#define vidrec
#define DATAPATH "/usr/share/fake86/"
#define CPU_TYPE 80186
#if defined(_WIN32)
    //#define NETWORKING_ENABLED
#endif
#ifdef LITTLE_ENDIAN
#else
#define LITTLE_ENDIAN
#endif

#define regax 0
#define regcx 1
#define regdx 2
#define regbx 3
#define regsp 4
#define regbp 5
#define regsi 6
#define regdi 7
#define reges 0
#define regcs 1
#define regss 2
#define regds 3
#if defined(__BIG_ENDIAN__)
     #define regal 1
     #define regah 0
     #define regcl 3
     #define regch 2
     #define regdl 5
     #define regdh 4
     #define regbl 7
     #define regbh 6
#else
     #define regal 0
     #define regah 1
     #define regcl 2
     #define regch 3
     #define regdl 4
     #define regdh 5
     #define regbl 6
     #define regbh 7
#endif

#define StepIP(x) ip+=x
#define getmem8(x,y) read86((x<<4)+y)
#define getmem16(x,y) (read86((x<<4)+y)|(read86((x<<4)+y+1)<<8))
#define putmem8(x,y,z) write86((x<<4)+y, z)
#define putmem16(x,y,z) write86((x<<4)+y, z&255); write86((x<<4)+y+1, z>>8)
#define signext(value) ((((uint16_t)value&0x80)*0x1FE)|(uint16_t)value)
#define signext32(value) ((((uint32_t)value&0x8000)*0x1FFFE)|(uint32_t)value)
#define getreg16(regid) regs.wordregs[regid]
#define getreg8(regid) regs.byteregs[byteregtable[regid]]
#define putreg16(regid, writeval) regs.wordregs[regid] = writeval
#define putreg8(regid, writeval) regs.byteregs[byteregtable[regid]] = writeval
#define getsegreg(regid) segregs[regid]
#define putsegreg(regid, writeval) segregs[regid] = writeval

#define modregrm() {\
	addrbyte = getmem8(segregs[regcs], ip); StepIP(1);\
	mode = addrbyte >> 6;\
	reg = (addrbyte >> 3) & 7;\
	rm = addrbyte & 7;\
	switch (mode) {\
		case 0:\
		if (rm == 6) { disp16 = getmem16(segregs[regcs], ip); StepIP(2); }\
		if (((rm == 2) || (rm == 3)) && !segoverride) useseg = segregs[regss]; break;\
		case 1:\
		disp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);\
		if (((rm == 2) || (rm == 3) || (rm == 6)) && !segoverride) useseg = segregs[regss]; break;\
		case 2:\
		disp16 = getmem16(segregs[regcs], ip); StepIP(2);\
		if (((rm == 2) || (rm == 3) || (rm == 6)) && !segoverride) useseg = segregs[regss]; break;\
		default:\
		disp8 = 0; disp16 = 0;\
	}\
}

#define getea(rmval) {\
	uint32_t tempea;\
	tempea = 0;\
	switch (mode) {\
		case 0:\
		switch (rmval) {\
			case 0: tempea = regs.wordregs[regbx] + regs.wordregs[regsi]; break;\
			case 1: tempea = regs.wordregs[regbx] + regs.wordregs[regdi]; break;\
			case 2: tempea = regs.wordregs[regbp] + regs.wordregs[regsi]; break;\
			case 3: tempea = regs.wordregs[regbp] + regs.wordregs[regdi]; break;\
			case 4: tempea = regs.wordregs[regsi]; break;\
			case 5: tempea = regs.wordregs[regdi]; break;\
			case 6: tempea = disp16; break;\
			case 7: tempea = regs.wordregs[regbx]; break;\
		} break;\
		case 1: case 2:\
		switch (rmval) {\
			case 0: tempea = regs.wordregs[regbx] + regs.wordregs[regsi] + disp16; break;\
			case 1: tempea = regs.wordregs[regbx] + regs.wordregs[regdi] + disp16; break;\
			case 2: tempea = regs.wordregs[regbp] + regs.wordregs[regsi] + disp16; break;\
			case 3: tempea = regs.wordregs[regbp] + regs.wordregs[regdi] + disp16; break;\
			case 4: tempea = regs.wordregs[regsi] + disp16; break;\
			case 5: tempea = regs.wordregs[regdi] + disp16; break;\
			case 6: tempea = regs.wordregs[regbp] + disp16; break;\
			case 7: tempea = regs.wordregs[regbx] + disp16; break;\
		} break;\
	}\
	ea = (tempea & 0xFFFF) + (useseg << 4);\
}

#define write86(addr32, value) {\
	tempaddr32 = addr32 & 0xFFFFF;\
	if (readonly[tempaddr32]) return;\
	switch (tempaddr32) {\
		case 0xA0000 ... 0xBFFFF:\
		if ((vidmode!=0x13) && (vidmode!=0x12) && (vidmode!=0xD) && (vidmode!=0x10)) RAM[addr32] = value;\
		else if (((VGA_SC[4] & 6)==0) && (vidmode!=0xD) && (vidmode!=0x10) && (vidmode!=0x12)) RAM[addr32] = value;\
		else writeVGA(addr32-0xA0000, value);\
		updatedscreen = 1;\
		default:\
		RAM[tempaddr32] = value;\
	}\
}

#define genaudio() {\
        if ((curtimer - lastssourcetimer) >= (timerfreq/7000)) {\
           ssourcecursample = getssourcebyte();\
           if (ssourcecursample>0) ssourcecursample -= 128;\
           lastssourcetimer = curtimer;\
        }\
	if ((curtimer - lastspeakertimer) >= (timerfreq/wanted.freq)) {\
	   accum = 0;\
	   samplestep = (samplestep + 1) % wanted.freq;\
	   for (curchan=0; curchan<9; curchan++) {\
		if (adlibfreq(curchan)!=0) {\
    		fullstep = wanted.freq/adlibfreq(curchan); halfstep = fullstep>>1;\
    		if (adlibstep[curchan]<halfstep) accum += (int32_t)((float)64*adlibenv[curchan]); else accum += (int32_t)((float)(-64)*adlibenv[curchan]);\
			adlibstep[curchan]++; if (adlibstep[curchan]>=fullstep) adlibstep[curchan] = 0;\
			if (adlibdidattack[curchan]) adlibenv[curchan] *= adlibdecay[curchan];\
			   else {\
			        adlibenv[curchan] *= adlibattack[curchan];\
			        if (adlibenv[curchan]>=1.0) adlibdidattack[curchan] = 1;\
               }\
		}\
      }\
        accum /= 10;\
        accum += ssourcecursample;\
		if (!speakercountdown) speakercountdown = 1;\
		speakerfreq = 1193180/speakercountdown;\
		if ((portram[0x61]&3)!=0) {\
			if (curstep<halfstep) accum += 20; else accum -= 20;\
			curstep++; if (curstep>=fullstep) curstep = 0;\
		}\
        cursample = (accum+128)&255;\
		buf[0][bufpos++] = cursample;\
		if (bufpos==wanted.samples) {\
			memcpy(&buf[1][0], &buf[0][0], wanted.samples);\
			if (audfile!=NULL) fwrite(&buf[0][0], wanted.samples, 1, audfile);\
			bufpos = 0;\
		}\
		lastspeakertimer = curtimer;\
	}\
}

#define timing() {\
   if ((totalexec&TIMERINTERVAL)==0) {\
   curtimer = totalexec;\
	if (doaudio=1) genaudio();\
	if (clocksafe && ((curtimer - lasttimer) >= timerticks)) {\
	    doirq(0);\
	    didticks++;\
		lasttimer = curtimer;\
	}\
	if ((curtimer - lastcurstimer) >= (timerfreq/3)) {\
		if (cursorvisible) cursorvisible = 0; else cursorvisible = 1;\
		lastcurstimer = curtimer; updatedscreen = 1;\
	}\
   }\
}
