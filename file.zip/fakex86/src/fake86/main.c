/*
This file is a part of Fake86 and (c)2010-2011 Mike Chambers
Fake86 homepage: http://fake86.rubbermallet.org
*/

#include <stdio.h>

#if defined(_WIN32)
#include <process.h>
#include <windows.h>
#else
#include <pthread.h>
#include <time.h>
#endif
#include "fake86.h"

const char *build = "v0.11.7.22";
extern void reset86();
extern void intcall86(uint8_t intnum);
extern uint8_t initaudio(), pktokay, recvplip;
extern uint64_t timerticks, realticks;
uint64_t secticks = 0, lastsecticks = 0;

#if defined(_WIN32)
FILE *outcon = NULL;
#else
pthread_t vidthread;
pthread_t timerthread;
#endif
FILE *audfile;
FILE *logfile;
extern uint8_t dopktrecv;

FILE *cassette;
char networking;
char msg[512];
void print(char *msg) {
	#if defined(_WIN32)
	fprintf(outcon, "%s", msg);
	fflush(outcon);
	#else
	printf("%s", msg);
	#endif
}

uint32_t loadbinary(uint32_t addr32, char *filename, uint8_t roflag) {
	uint32_t fsize;
	FILE *binfile;
	uint32_t i;
	//#if defined(_WIN32)
		binfile = fopen(filename, "rb");
	//#else
		//char *tmppath;
		//sprintf(tmppath, "%s%s", DATAPATH, filename);
		//binfile = fopen(tmppath, "rb");
	//#endif
	if (binfile == NULL) {
		sprintf(msg, "Warning: Failed to open %s\n", filename); print(msg);
		return;
	}
	fseek(binfile, 0L, SEEK_END);
	fsize = ftell(binfile);
	fseek(binfile, 0L, SEEK_SET);
	fsize = fread(&RAM[addr32], 1, fsize, binfile);
	fclose(binfile);
	for (i=addr32; i<fsize; i++) readonly[i] = roflag;
	return(fsize);
}

uint8_t scrmodechange = 0;
extern uint8_t monitorflag, monmodechange;
uint16_t oldw, oldh;
void VideoThread(void *dummy) {
	while (running) {
		if (updatedscreen) {
     	   updatedscreen = 0;
		   MutexLock(screenmutex);
		   if (monitorflag==0) draw();
		      else drawmonitor();
		   if (scrmodechange) screen = SDL_SetVideoMode(screen->w, screen->h, 32, SDL_HWSURFACE | usefullscreen);
		   if (monmodechange==1) {
              oldw = screen->w; oldh = screen->h;
              screen = SDL_SetVideoMode(640, 400, 32, SDL_HWSURFACE | usefullscreen);
           } else if (monmodechange==2) {
              screen = SDL_SetVideoMode(oldw, oldh, 32, SDL_HWSURFACE | usefullscreen);
              monitorflag = 0;
           }
		   scrmodechange = 0; monmodechange = 0;
		   MutexUnlock(screenmutex);
        }
		SDL_Delay(30);
	}
}

extern void parsecl();
#if defined(NETWORKING_ENABLED)
extern struct netstruct {
       uint8_t enabled;
       uint8_t canrecv;
       uint16_t pktlen;
} net;
#endif
float timercomp = 1.0;
extern uint64_t didwhen, didticks;
uint64_t lastdidwhen = 0, oldfreq;
uint32_t timestart;

int main(int argc, char *argv[]) {
	#if defined(_WIN32)
	outcon = fopen("CON", "w");
	#endif
	
	sprintf(msg, "Fake86 %s (c)2010-2011 Mike Chambers\n[A portable 8086 PC emulator]\n\n", build); print(msg);
	parsecl(argc, argv);
	
	#if defined(NETWORKING_ENABLED)
	    if (ethif!=254) initpcap();
	#endif
    timerfreq = 1000000;
	if (SDL_Init(SDL_INIT_EVERYTHING)) {
		sprintf(msg, "SDL failed to initialize!\n"); print(msg);
		return(1);
	}
	loadbinary(0xFE000, "/usr/share/fake86/xtbios.bin", 1);
	loadbinary(0xF6000, "/usr/share/fake86/rombasic.bin", 1);
	loadbinary(0xC0000, "/usr/share/fake86/et4000.bin", 1);
	//loadbinary(0xFC000, "/usr/share/fake86/tandy.bin", 1);
	oplistgen();
	reset86();
	initcga();
	videobase = textbase;
	pit0divisor = 65536;
	cols = 80; rows = 25;
	#if defined(NETWORKING_ENABLED)
	    net.canrecv = 0;
	    net.enabled = 0;
    #endif
	running = 1;
	
	if (doaudio==1) initaudio();
	
	#if defined(CONSOLE)
	#else
    screen = SDL_SetVideoMode(640, 400, 32, SDL_HWSURFACE);
   	if (screen == NULL) {
		sprintf(msg, "Couldn't set 640x400x32 video mode: %s\n", SDL_GetError ()); print(msg);
		exit (2);
	}
	sprintf(msg, "Fake86 %s", build);
	SDL_WM_SetCaption(msg, NULL);
	#if defined(_WIN32)
	    screenmutex = CreateMutex(NULL, FALSE, NULL);
	    _beginthread(VideoThread, 0, NULL);
	#else
	     pthread_create(&vidthread, NULL, VideoThread, NULL);
	#endif
	#endif
	char didmodeswitch = 0;
	char keydown[256];
	#if defined(_WIN32)
        timeBeginPeriod(1);
    #endif
    timestart = SDL_GetTicks();
    uint64_t ipsloop, ipscount;
    memset(&keydown[0], 0, 256); //make sure this array is initialized to zeroes, otherwise the world implodes
    memset(&portram[0], 0, 0xFFFF * 2); //same here
	while(running) {
        #if defined(NETWORKING_ENABLED)
		    if (net.enabled) dispatch();
		#endif
		exec86(5000);
        didwhen = SDL_GetTicks();
		if ((didwhen - lastdidwhen)>=100) {
           secticks = totalexec - lastsecticks;
           ips[9] = ips[8];
           ips[8] = ips[7];
           ips[7] = ips[6];
           ips[6] = ips[5];
           ips[5] = ips[4];
           ips[4] = ips[3];
           ips[3] = ips[2];
           ips[2] = ips[1];
           ips[1] = ips[0];
           ips[0] = secticks*10;
           ipscount = 0;
           timerfreq = 0;
           for (ipsloop=1; ipsloop<10; ipsloop++) {
               timerfreq += ips[ipsloop];
               if (ips[ipsloop]) ipscount++;
           }
           if (ipscount==0) ipscount = 1;
           timerfreq /= ipscount;
           timerfreq = (timerfreq + ips[0]) >> 1;
           lastdidwhen = didwhen;
		   if (pit0divisor==0) pit0divisor = 65536;
		   timerticks = timerfreq/(1193180/pit0divisor);
		   lastsecticks = totalexec;
           didticks = 0;
           
           #if defined(_WIN32)
           //keep emulator's time of day clock synchronized with the real world value
           temp1 = (uint32_t)getmem16(0x40, 0x6C) | ((uint32_t)getmem16(0x40, 0x6E) << 16);
           temp2 = dayticks();
           if ((temp2 + 1000) < temp1) write86(0x470, 1); //set midnight flag if appropriate
           putmem16(0x40, 0x6C, (temp2 & 0xFFFF));
           putmem16(0x40, 0x6E, (temp2 >> 16));
           #endif
        }
		SDL_Event event;
		if (SDL_PollEvent (&event)) {
			switch (event.type) {
				case SDL_KEYDOWN:
                if (monitorflag) { monitorkeypress(event.key.keysym.sym); break; }
				portram[0x60] = translatescancode(event.key.keysym.sym);
				portram[0x63] = 2;
				doirq(1);
				keydown[translatescancode(event.key.keysym.sym)] = 1;
				if (keydown[0x1D] && keydown[0x38] && keydown[0x1C]) {
                   if (didmodeswitch==0) {
                    MutexLock(screenmutex);
                    if (usefullscreen==0) {
                      usefullscreen = SDL_FULLSCREEN;
                      scrmodechange = 1;
                    } else {
                      usefullscreen = 0;
                      scrmodechange = 1;
                    }
                    MutexUnlock(screenmutex);
                   }
                   didmodeswitch = 1;
                } else didmodeswitch = 0;
				if (keydown[0x1D] && keydown[0x38] && keydown[0x32]) {
                   keydown[0x1D] = 0; keydown[0x38] = 0; keydown[0x32] = 0;
                   runmonitor();
                }   
				break;
				case SDL_KEYUP:
                if (monitorflag)
                   switch (event.key.keysym.sym) {
                          case 0x12F ... 0x130:
                               monitorkeypress(event.key.keysym.sym | 0x8000);
                               break;
                   }
				portram[0x60] = translatescancode(event.key.keysym.sym) + 0x80;
				portram[0x63] = 2;
				doirq(1);
				keydown[translatescancode(event.key.keysym.sym)] = 0;
				break;
				case SDL_QUIT:
				running = 0;
				break;
				default:
				break;
			}
		}
	}
	sprintf(msg, "%llu instructions were executed in %lu seconds.\nAverage speed: %llu\n", totalexec, (SDL_GetTicks() - timestart) / 1000, totalexec / ((SDL_GetTicks() - timestart) / 1000));
	print(msg);
	#if defined(_WIN32)
	    timeEndPeriod(1);
	#endif
	return(0);
}

