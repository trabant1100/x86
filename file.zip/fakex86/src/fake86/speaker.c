#include "common.h"

SDL_AudioSpec wanted;
uint8_t buf[2][44100], reentry = 0;
uint32_t bufpos, framenum = 0;

void fill_audio(void *udata, uint8_t *stream, int len) {
     uint16_t derp;     
     if (reentry==1) return;
     reentry = 1;
    memcpy(stream, &buf[1][0], len);
    #if defined(vidrec)
    if (vidmode==0x13) {
       sprintf(msg, "c:\\bmp\\%u.bmp", framenum++);
       SDL_SaveBMP(screen, msg);
       if (audfile!=NULL) fwrite(&buf[1][0], 1, wanted.samples, audfile);
    }
    #endif
    reentry = 0;
}

uint8_t initaudio() {
    sprintf(msg, "Initializing audio stream... "); print(msg);
    wanted.freq = 44100;
    wanted.format = AUDIO_U8;
    wanted.channels = 1;
    wanted.samples = 2048;
    wanted.callback = fill_audio;
    wanted.userdata = NULL;
    
    if (SDL_OpenAudio(&wanted, NULL)<0) {
        sprintf(msg, "Error: %s\n", SDL_GetError()); print(msg);
        return(-1);
} else { sprintf(msg, "OK!\n"); print(msg); }
    
    memset(&buf[0][0], 128, 88200);
    SDL_PauseAudio(0);
    return(0);
}
