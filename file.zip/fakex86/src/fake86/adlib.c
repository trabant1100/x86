#include "common.h"

uint8_t optable[0x16] = { 0, 0, 0, 1, 1, 1, 255, 255, 0, 0, 0, 1, 1, 1, 255, 255, 0, 0, 0, 1, 1, 1 };
uint16_t adlibregmem[0xFF], adlibaddr = 0;
int8_t waveform[4][64] = {
        { 1, 8, 13, 20, 26, 31, 37, 41, 47, 49, 54, 58, 58, 62, 63, 63, 64, 63, 62, 61, 58, 55, 52, 47, 45, 38, 34, 27, 23, 17, 10, 4,-2,-8,-15,-21,-26,-34,-36,-42,-48,-51,-54,-59,-60,-62,-64,-65,-65,-63,-64,-61,-59,-56,-53,-48,-46,-39,-36,-28,-24,-17,-11,-6 },
        { 1, 8, 13, 20, 25, 32, 36, 42, 46, 50, 54, 57, 60, 61, 62, 64, 63, 65, 61, 61, 58, 55, 51, 49, 44, 38, 34, 28, 23, 16, 11, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 1, 8, 13, 21, 25, 31, 36, 43, 45, 50, 54, 57, 59, 62, 63, 63, 63, 64, 63, 59, 59, 55, 52, 48, 44, 38, 34, 28, 23, 16, 10, 4, 2, 7, 14, 20, 26, 31, 36, 42, 45, 51, 54, 56, 60, 62, 62, 63, 65, 63, 62, 60, 58, 55, 52, 48, 44, 38, 34, 28, 23, 17, 10, 3 },
        { 1, 8, 13, 20, 26, 31, 36, 42, 46, 51, 53, 57, 60, 62, 61, 66, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 13, 21, 25, 32, 36, 41, 47, 50, 54, 56, 60, 62, 61, 67, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
};

struct structadlibop {
       uint8_t wave;
} adlibop[9][2];

struct structadlibchan {
       uint16_t freq;
       float convfreq;
       uint8_t keyon;
       uint16_t octave;
       uint8_t wavesel;
} adlibch[9];

float attacktable[16] = { 1.0001, 1.0002, 1.0003, 1.0004, 1.0005, 1.0006, 1.0007, 1.0008, 1.0009, 1.001, 1.0011, 1.0012, 1.0013, 1.0014, 1.0015, 1.0016 };
//float attacktable[16] = { 1.0002, 1.0003, 1.0004, 1.0008, 1.0016, 1.0032, 1.0064, 1.0128, 1.0256, 1.0512, 1.1024, 1.2048, 1.4096, 1.8192, 2.6384, 4.2768 };
//float attacktable[16] = { 1.0001, 1.00025, 1.0005, 1.00075, 1.001, 1.0025, 1.005, 1.0001, 1.0001, 1.0001, 1.0001, 1.0001, 1.0001, 1.0001, 1.0001, 1.0001 };
float decaytable[16] = { 0.999999, 0.999998, 0.999997, 0.999993, 0.99997, 0.99993, 0.99986, 0.9998, 0.9994, 0.9991, 0.9987, 0.9978, 0.9970, 0.99940, 0.9992, 0.999 };
float adlibenv[9], adlibdecay[9], adlibattack[9];
uint8_t adlibdidattack[9], adlibstatus = 0;

uint16_t adlibport = 0x388;

void outadlib(uint16_t portnum, uint8_t value) {
     int dbgchan;
     if (portnum==adlibport) { adlibaddr = value; return; }
     portnum = adlibaddr;
     adlibregmem[portnum] = value;
     switch (portnum) {
            case 4: //timer control
                 if (value&0x80) { adlibstatus = 0; adlibregmem[4] = 0; }
                 break;
            case 0x60 ... 0x75: //attack/decay
                 portnum &= 15;
                 //value = 0xF0;
                 adlibattack[portnum] = attacktable[value>>4]*1.025;
                 adlibdecay[portnum] = decaytable[value&15];
                 break;
            case 0xA0 ... 0xB8: //octave, freq, key on
                 portnum &= 15;
                 //if (!adlibch[portnum].keyon &&((adlibregmem[0xB0+portnum]>>5)&1)) {
                    adlibdidattack[portnum] = 0;
                    adlibenv[portnum] = 0.0025;
                 //}
                 adlibch[portnum].freq = adlibregmem[0xA0+portnum] | ((adlibregmem[0xB0+portnum]&3)<<8);
                 adlibch[portnum].convfreq = ((float)adlibch[portnum].freq * 0.7626459);
                 adlibch[portnum].keyon = (adlibregmem[0xB0+portnum]>>5)&1;
                 adlibch[portnum].octave = (adlibregmem[0xB0+portnum]>>2)&7;
                 break;
            case 0xE0 ... 0xF5: //waveform select
                 portnum &= 15;
                 if (portnum<9) adlibch[portnum].wavesel = value&3;
                 break;
     }
     /*for (dbgchan=0; dbgchan<9; dbgchan++) {
         sprintf(msg, "%u", adlibch[dbgchan].keyon); print(msg);
     } sprintf(msg, "         %f Hz           \r", adlibch[0].convfreq); print(msg);*/
}

uint8_t inadlib(uint16_t portnum) {
        if (!adlibregmem[4]) adlibstatus = 0; else adlibstatus = 0x80;
        adlibstatus = adlibstatus + (adlibregmem[4]&1)*0x40 + (adlibregmem[4]&2)*0x10;
        return(adlibstatus);
}

uint16_t adlibfreq(uint8_t chan) {
         uint8_t downoct[4] = { 3, 2, 1, 0 };
         uint8_t upoct[3] = { 1, 2, 3 };
         uint16_t tmpfreq, cntshift;
         if (!adlibch[chan].keyon) return(0);
         tmpfreq = (uint16_t)adlibch[chan].convfreq;
         //if (adlibch[chan].octave<4) tmpfreq = tmpfreq>>1;
         //if (adlibch[chan].octave>4) tmpfreq = tmpfreq<<1;
         switch (adlibch[chan].octave) {
                case 0: tmpfreq = tmpfreq >> 4; break;
                case 1: tmpfreq = tmpfreq >> 3; break;
                case 2: tmpfreq = tmpfreq >> 2; break;
                case 3: tmpfreq = tmpfreq >> 1; break;
                //case 4: tmpfreq = tmpfreq >> 1; break;
                case 5: tmpfreq = tmpfreq << 1; break;
                case 6: tmpfreq = tmpfreq << 2; break;
                case 7: tmpfreq = tmpfreq << 3;
         }
         
         /*if (adlibch[chan].octave<4) {
            for (cntshift=0; cntshift<downoct[adlibch[chan].octave]; cntshift++)
                tmpfreq = tmpfreq>>1;
         } else {
            for (cntshift=0; cntshift<upoct[adlibch[chan].octave]; cntshift++)
                tmpfreq = tmpfreq<<1;
         }*/
         return(tmpfreq);
}
