#include "common.h"
uint8_t monitorflag = 0, monmodechange = 0, monx = 0, mony = 0;
uint8_t monscreen[2000];
uint16_t savew, saveh;

void drawmonitor() {
    uint32_t color, chary, charx, vidptr, divx, divy, curchar, curheight, blockw, x1, y1;
    int32_t ofs, maxptr, *bufp;
    if (SDL_MUSTLOCK(screen)) 
      if (SDL_LockSurface(screen) < 0) 
        return;
        maxptr = screen->w*screen->h - 1;
            for (y=0; y<400; y++)
                for (x=0; x<640; x++) {
                    charx = x/8; divx = 1;
                        chary = y/16;
                        vidptr = chary*80 + charx;
                        curchar = monscreen[vidptr];
                        color = fontcga[curchar*128 + (y%16)*8 + ((x/divx)%8)];
                        if (!color) color = palettecga[0];
                                else color = palettecga[7];
                    ofs = y*screen->w + x;
                    if ((ofs >= 0) && (ofs <= maxptr))
                       ((uint32_t *)screen->pixels)[ofs] = SDL_MapRGB(screen->format, color&255, (color>>8)&255, color>>16);
                }

            	if (cursorvisible) {
             		curheight = 2;
                 		x1 = monx * 8;
                   		y1 = mony * 8 + 8 - curheight;
                     	for (y=y1*2; y<=y1*2+curheight-1; y++)
                     		for (x=x1; x<=x1+7; x++) {
                       			color = palettecga[7];
                                ofs = y*screen->w + x;
                                if ((ofs >= 0) && (ofs <= maxptr))
                                   ((uint32_t *)screen->pixels)[ofs] = SDL_MapRGB(screen->format, color&255, (color>>8)&255, color>>16);
                          }
                 }

    if (SDL_MUSTLOCK(screen)) 
      SDL_UnlockSurface(screen);
    SDL_UpdateRect(screen, 0, 0, screen->w, screen->h);
}

void mprint(char *text) {
     uint8_t cc;
     uint16_t textpos = 0, scrollptr;
     while(1) {
              cc = text[textpos++];
              switch (cc) {
                     case 0:
                     case 13:
                          return;
                     case 8:
                          if (monx>0) monx--;
                          break;
                     case 10:
                          monx = 0; mony++;
                          break;
                     default:
                          monscreen[mony*80+monx] = cc;
                          monx++;
                          break;
              }
              if (monx>79) { monx = 0; mony++; }
              if (mony>24) {
                 mony = 24;
                 for (scrollptr=80; scrollptr<2000; scrollptr++) {
                     monscreen[scrollptr - 80] = monscreen[scrollptr];
                 }
                 memset(&monscreen[1920], 0, 80);
              }
     }
}

uint8_t ismatch(char *s1, char *s2, uint16_t slen) {
        uint16_t tmppos;
        for (tmppos=0; tmppos<slen; tmppos++)
            if (s1[tmppos] != s2[tmppos]) return(0);
        return(1);
}

uint8_t isimatch(char *s1, char *s2, uint16_t slen) { //case insensitive ismatch
        uint16_t tmppos;
        for (tmppos=0; tmppos<slen; tmppos++) {
            //if ((s1[tmppos]>=97) && (s1[tmppos]<=122)) s1[tmppos] -= 32;
            //if ((s2[tmppos]>=97) && (s2[tmppos]<=122)) s2[tmppos] -= 32;
            if (s1[tmppos] != s2[tmppos]) return(0);
        }
        return(1);
}

uint8_t monitorinput[256], inputpos = 0, monitorshift = 0;
void monitorparseline() {
     mprint("\n");
     if (isimatch("exit", &monitorinput[0], 4)) {
        monmodechange = 2;
     } else if (isimatch("fd0=", &monitorinput[0], 4)) {
        if (insertdisk(0, &monitorinput[4])==0) mprint("Disk image changed for fd0.\n");
           else mprint("Error changing disk image for fd0!\n");
     } else if (isimatch("fd1=", &monitorinput[0], 4)) {
        if (insertdisk(1, &monitorinput[4])) mprint("Disk image changed for fd1.\n");
           else mprint("Error changing disk image for fd1!\n");
     } else mprint("Invalid command.\n");
     memset(&monitorinput[0], 0, 256); inputpos = 0;
     mprint(">");
}

void monitorkeypress(uint16_t keycode) {
     //sprintf(msg, "%04X\n", keycode); mprint(msg);
     switch (keycode) {
            case 0:
                 break;
            case 8: //backspace
                 if (inputpos>0) {
                    monitorinput[--inputpos] = 0;
                    sprintf(msg, "%c %c", 8, 8); mprint(msg);
                 } break;
            case 13:
                 monitorinput[inputpos] = 0;
                 monitorparseline();
                 break;
            case 0x12F ... 0x130: //shift
                 monitorshift = 1;
                 break;
            case 0x812F ... 0x8130: //depress shift
                 monitorshift = 0;
                 break;
            default:
                 if (inputpos==255) break;
                 if (monitorshift) {
                    switch (keycode) {
                           case 97 ... 122: keycode -= 32; break;
                           case '`': keycode = '~'; break;
                           case '1': keycode = '!'; break;
                           case '2': keycode = '@'; break;
                           case '3': keycode = '#'; break;
                           case '4': keycode = '$'; break;
                           case '5': keycode = '%'; break;
                           case '6': keycode = '^'; break;
                           case '7': keycode = '&'; break;
                           case '8': keycode = '*'; break;
                           case '9': keycode = '('; break;
                           case '0': keycode = ')'; break;
                           case '-': keycode = '_'; break;
                           case '=': keycode = '+'; break;
                           case ';': keycode = ':'; break;
                           case ',': keycode = '<'; break;
                           case '.': keycode = '>'; break;
                           case '[': keycode = '{'; break;
                           case ']': keycode = '}'; break;
                    }
                 }
                 monitorinput[inputpos++] = keycode;
                 sprintf(msg, "%c", keycode & 0xFF); mprint(msg);
     }
}

uint8_t monfirstrun = 1;
void runmonitor() {
     if (monitorflag) return;
     monitorflag = 1;
     savew = screen->w;
     saveh = screen->h;
     memset(&monitorinput[0], 0, 256);
     monmodechange = 1;
     inputpos = 0;
     if (monfirstrun) mprint("Fake86 Monitor v1.0\n\n>");
     monfirstrun = 0;
}

void exitmonitor() {
     screen = SDL_SetVideoMode(savew, saveh, 32, SDL_HWSURFACE | usefullscreen);
     monitorflag = 0;
}
