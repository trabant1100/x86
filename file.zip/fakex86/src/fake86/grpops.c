#include "common.h"

extern void intcall86(uint8_t intnum);

uint8_t op_grp2_8(uint8_t cnt) {
	uint16_t d, s, shift, oldcf, msb;
	//if (cnt>0x8) return(oper1b); //80186+ limits shift count
	s = oper1b;
	oldcf = cf;
	switch (reg) {
		case 0: //ROL r/m8
		for (shift=1; shift<=cnt; shift++) {
			if (s & 0x80) cf = 1; else cf = 0;
			s = s << 1;
			s = s | cf;
		}
		if (cnt==1) of = cf ^ ((s >> 7) & 1);
		break;
		
		case 1: //ROR r/m8
		for (shift=1; shift<=cnt; shift++) {
			cf = s & 1;
			s = (s >> 1) | (cf << 7);
		}
		if (cnt==1) of = (s >> 7) ^ ((s >> 6) & 1);
		break;
		
		case 2: //RCL r/m8
		for (shift=1; shift<=cnt; shift++) {
			oldcf = cf;
			if (s & 0x80) cf = 1; else cf = 0;
			s = s << 1;
			s = s | oldcf;
		}
		if (cnt==1) of = cf ^ ((s >> 7) & 1);
		break;
		
		case 3: //RCR r/m8
		for (shift=1; shift<=cnt; shift++) {
			oldcf = cf;
			cf = s & 1;
			s = (s >> 1) | (oldcf << 7);
		}
		if (cnt==1) of = (s >> 7) ^ ((s >> 6) & 1);
		break;
		
		case 4: case 6: //SHL r/m8
		for (shift=1; shift<=cnt; shift++) {
			if (s & 0x80) cf = 1; else cf = 0;
			s = (s << 1) & 0xFF;
		}
		if ((cnt==1) && (cf==(s>>7))) of = 0; else of = 1;
		flag_szp8(s); break;
		
		case 5: //SHR r/m8
		if ((cnt==1) && (s & 0x80)) of = 1; else of = 0;
		for (shift=1; shift<=cnt; shift++) {
			cf = s & 1;
			s = s >> 1;
		}
		flag_szp8(s); break;
		
		case 7: //SAR r/m8
		for (shift=1; shift<=cnt; shift++) {
			msb = s & 0x80;
			cf = s & 1;
			s = (s >> 1) | msb;
		}
		of = 0;
		flag_szp8(s); break;
		
	}
	return(s & 0xFF);
}

uint16_t op_grp2_16(uint8_t cnt) {
	uint32_t d, s, shift, oldcf, msb;
	//if (cnt>0x10) return(oper1); //80186+ limits shift count
	s = oper1;
	oldcf = cf;
	switch (reg) {
		case 0: //ROL r/m8
		for (shift=1; shift<=cnt; shift++) {
			if (s & 0x8000) cf = 1; else cf = 0;
			s = s << 1;
			s = s | cf;
		}
		if (cnt==1) of = cf ^ ((s >> 15) & 1);
		break;
		
		case 1: //ROR r/m8
		for (shift=1; shift<=cnt; shift++) {
			cf = s & 1;
			s = (s >> 1) | (cf << 15);
		}
		if (cnt==1) of = (s >> 15) ^ ((s >> 14) & 1);
		break;
		
		case 2: //RCL r/m8
		for (shift=1; shift<=cnt; shift++) {
			oldcf = cf;
			if (s & 0x8000) cf = 1; else cf = 0;
			s = s << 1;
			s = s | oldcf;
		}
		if (cnt==1) of = cf ^ ((s >> 15) & 1);
		break;
		
		case 3: //RCR r/m8
		for (shift=1; shift<=cnt; shift++) {
			oldcf = cf;
			cf = s & 1;
			s = (s >> 1) | (oldcf << 15);
		}
		if (cnt==1) of = (s >> 15) ^ ((s >> 14) & 1);
		break;
		
		case 4: case 6: //SHL r/m8
		for (shift=1; shift<=cnt; shift++) {
			if (s & 0x8000) cf = 1; else cf = 0;
			s = (s << 1) & 0xFFFF;
		}
		if ((cnt==1) && (cf==(s>>15))) of = 0; else of = 1;
		flag_szp16(s); break;
		
		case 5: //SHR r/m8
		if ((cnt==1) && (s & 0x8000)) of = 1; else of = 0;
		for (shift=1; shift<=cnt; shift++) {
			cf = s & 1;
			s = s >> 1;
		}
		flag_szp16(s); break;
		
		case 7: //SAR r/m8
		for (shift=1; shift<=cnt; shift++) {
			msb = s & 0x8000;
			cf = s & 1;
			s = (s >> 1) | msb;
		}
		of = 0;
		flag_szp16(s); break;
		
	}
	return(s & 0xFFFF);
}

inline void op_div8(uint16_t valdiv, uint8_t divisor) {
	if (divisor==0) { intcall86(0); return; }
	if ((valdiv / (uint16_t)divisor) > 0xFF) { intcall86(0); return; }
	regs.byteregs[regah] = valdiv % (uint16_t)divisor;
	regs.byteregs[regal] = valdiv / (uint16_t)divisor;
}

inline void op_idiv8(uint16_t valdiv, uint8_t divisor) {
	uint16_t v1, v2, s1, s2, d1, d2;
	int sign;
	if (divisor==0) { intcall86(0); return; }
	s1 = valdiv;
	s2 = divisor;
	sign = (((s1 ^ s2) & 0x8000) != 0);
	s1 = (s1 < 0x8000) ? s1 : ((~s1 + 1) & 0xffff);
	s2 = (s2 < 0x8000) ? s2 : ((~s2 + 1) & 0xffff);
	d1 = s1 / s2;
	d2 = s1 % s2;
	if (d1 & 0xFF00) { intcall86(0); return; }
	if (sign) {
		d1 = (~d1 + 1) & 0xff;
		d2 = (~d2 + 1) & 0xff;
	}
	regs.byteregs[regah] = d2;
	regs.byteregs[regal] = d1;
	//if (valdiv > 32767) v1 = valdiv - 65536; else v1 = valdiv;
	//if (divisor > 127) v2 = divisor - 256; else v2 = divisor;
	//v1 = valdiv;
	//v2 = signext(divisor);
	//if ((v1/v2) > 255) { intcall86(0); return; }
	//regs.byteregs[regal] = (v1/v2) & 255;
	//regs.byteregs[regah] = (v1 % v2) & 255;
}

void op_grp3_8() {
	uint32_t d1, d2, s1, s2, sign;
	uint16_t d, s;
	oper1 = signext(oper1b); oper2 = signext(oper2b);
	switch (reg) {
		case 0: case 1: //TEST
		flag_log8(oper1b & getmem8(segregs[regcs], ip)); StepIP(1);
		break;
		
		case 2: //NOT
		res8 = ~oper1b; break;
		
		case 3: //NEG
		res8 = (~oper1b)+1;
		flag_sub8(0, oper1b);
		if (res8==0) cf = 0; else cf = 1;
		break;
		
		case 4: //MUL
		temp1 = (uint32_t)oper1b * (uint32_t)regs.byteregs[regal];
		regs.wordregs[regax] = temp1 & 0xFFFF;
		flag_szp8(temp1);
		if (regs.byteregs[regah]) { cf = 1; of = 1; } else { cf = 0; of = 0; }
		break;
		
		case 5: //IMUL
		oper1 = signext(oper1b);
		temp1 = signext(regs.byteregs[regal]);
		temp2 = oper1;
		if ((temp1 & 0x80)==0x80) temp1 = temp1 | 0xFFFFFF00;
		if ((temp2 & 0x80)==0x80) temp2 = temp2 | 0xFFFFFF00;
		temp3 = (temp1 * temp2) & 0xFFFF;
		regs.wordregs[regax] = temp3 & 0xFFFF;
		if (regs.byteregs[regah]) { cf = 1; of = 1; } else { cf = 0; of = 0; }
		break;
		
		case 6: //DIV
		op_div8(getreg16(regax), oper1b);
		break;
		
		case 7: //IDIV
		op_idiv8(getreg16(regax), oper1b);
		break;
	}
}

inline void op_div16(uint32_t valdiv, uint16_t divisor) {
	uint16_t v1, v2;
	if (divisor==0) { intcall86(0); return; }
	if ((valdiv / (uint32_t)divisor) > 0xFFFF) { intcall86(0); return; }
	putreg16(regdx, valdiv % (uint32_t)divisor);
	putreg16(regax, valdiv / (uint32_t)divisor);
}

inline void op_idiv16(uint32_t valdiv, uint16_t divisor) {
	uint32_t v1, v2, d1, d2, s1, s2;
	int sign;
	if (divisor==0) { intcall86(0); return; }
	s1 = valdiv;
	s2 = divisor;
	s2 = (s2 & 0x8000) ? (s2 | 0xffff0000) : s2;
	sign = (((s1 ^ s2) & 0x80000000) != 0);
	s1 = (s1 < 0x80000000) ? s1 : ((~s1 + 1) & 0xffffffff);
	s2 = (s2 < 0x80000000) ? s2 : ((~s2 + 1) & 0xffffffff);
	d1 = s1 / s2;
	d2 = s1 % s2;
	if (d1 & 0xFFFF0000) { intcall86(0); return; }
	if (sign) {
		d1 = (~d1 + 1) & 0xffff;
		d2 = (~d2 + 1) & 0xffff;
	}
	regs.wordregs[regax] = d1;
	regs.wordregs[regdx] = d2;
	//if (valdiv > 0x7FFFFFFF) v1 = valdiv - 0xFFFFFFFF - 1; else v1 = valdiv;
	//if (divisor > 32767) v2 = divisor - 65536; else v2 = divisor;
	//if ((v1/v2) > 65535) { intcall86(0); return; }
	//temp3 = (v1/v2) & 65535;
	//regs.wordregs[regax] = temp3;
	//temp3 = (v1%v2) & 65535;
	//regs.wordregs[regdx] = temp3;
}

void op_grp3_16() {
	uint32_t d1, d2, s1, s2, sign;
	uint16_t d, s;
	//oper1 = signext(oper1b); oper2 = signext(oper2b);
	//sprintf(msg, "  Oper1: %04X    Oper2: %04X\n", oper1, oper2); print(msg);
	switch (reg) {
		case 0: case 1: //TEST
		flag_log16(oper1 & getmem16(segregs[regcs], ip)); StepIP(2); break;
		case 2: //NOT
		res16 = ~oper1; break;
		case 3: //NEG
		res16 = (~oper1) + 1;
		flag_sub16(0, oper1);
		if (res16) cf = 1; else cf = 0;
		break;
		case 4: //MUL
		temp1 = (uint32_t)oper1 * (uint32_t)getreg16(regax);
		putreg16(regax, temp1 & 0xFFFF);
		putreg16(regdx, temp1 >> 16);
		flag_szp16(temp1);
		if (getreg16(regdx)) { cf = 1; of = 1; } else { cf = 0; of = 0; }
		break;
		case 5: //IMUL
		temp1 = getreg16(regax);
		temp2 = oper1;
		if (temp1 & 0x8000) temp1 |= 0xFFFF0000;
		if (temp2 & 0x8000) temp2 |= 0xFFFF0000;
		temp3 = temp1 * temp2;
		putreg16(regax, temp3 & 0xFFFF); //into register ax
		putreg16(regdx, temp3 >> 16); //into register dx
		if (getreg16(regdx)) { cf = 1; of = 1; } else { cf = 0; of = 0; }
		break;
		case 6: //DIV
		op_div16(((uint32_t)getreg16(regdx)<<16) + getreg16(regax), oper1); break;
		case 7: //DIV
		op_idiv16(((uint32_t)getreg16(regdx)<<16) + getreg16(regax), oper1); break;
	}
}

void op_grp5() {
	switch (reg) {
		case 0: //INC Ev
		oper2 = 1;
		tempcf = cf;
		op_add16();
		cf = tempcf;
		writerm16(rm, res16); break;
		case 1: //DEC Ev
		oper2 = 1;
		tempcf = cf;
		op_sub16();
		cf = tempcf;
		writerm16(rm, res16); break;
		case 2: //CALL Ev
		push(ip);
		ip = oper1; break;
		case 3: //CALL Mp
		push(segregs[regcs]); push(ip);
		getea(rm);
		ip = (uint16_t)read86(ea) + (uint16_t)read86(ea + 1) * 256;
		segregs[regcs] = (uint16_t)read86(ea + 2) + (uint16_t)read86(ea + 3) * 256; break;
		case 4: //JMP Ev
		ip = oper1; break;
		case 5: //JMP Mp
		getea(rm);
		ip = (uint16_t)read86(ea) + (uint16_t)read86(ea + 1) * 256;
		segregs[regcs] = (uint16_t)read86(ea + 2) + (uint16_t)read86(ea + 3) * 256; break;
		case 6: //PUSH Ev
		push(oper1); break;
	}
}

