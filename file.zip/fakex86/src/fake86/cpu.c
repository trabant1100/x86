#include "common.h"
#define TIMERINTERVAL 15

uint16_t newoffs = 0;
uint8_t interrupt_ok = 0, savesp;
extern uint8_t dopktrecv, pktokay;
extern uint16_t rcvseg, rcvoff, hdrlen, handpkt;

extern struct struct_drive {
        FILE *diskfile;
        uint32_t filesize;
        uint16_t cyls;
        uint16_t sects;
        uint16_t heads;
        uint8_t inserted;
} disk[256];
//extern uint8_t readVGA(uint32_t addr32);

uint8_t read86(uint32_t addr32) {
        addr32 &= 0xFFFFF;
/*      if (clocksafe && (addr32>=0x48C) && (addr32<=0x500)) {
       sprintf(msg, "BDA read: %05X\n", addr32); print(msg);
    }*/
        switch (addr32) {
        //case (0x60<<4) ... ((0x60<<4)+2): return(0);
        //case (0x60<<4)+3: return(0xF0);
                case 0x410: //0040:0010 is the equipment word
                return(0x61); //report CGA video
                //case 0x472:
                //    return(0x34);
                //case 0x473:
                //    return(0x12);
                case 0x475: //hard drive count
                return(hdcount);
                case 0xA0000 ... 0xBFFFF:
                if ((vidmode!=0x13) && (vidmode!=0x12) && (vidmode!=0xD)) return(RAM[addr32]);
                if ((VGA_SC[4] & 6)==0) return(RAM[addr32]); else return(readVGA(addr32-0xA0000));
                default:
                return(RAM[addr32]);
        }
}

void push(pushval) {
        regs.wordregs[regsp] = regs.wordregs[regsp] - 2;
        putmem16(segregs[regss], regs.wordregs[regsp], pushval);
}

uint16_t pop() {
        uint16_t tempval;
        tempval = getmem16(segregs[regss], regs.wordregs[regsp]);
        regs.wordregs[regsp] = regs.wordregs[regsp] + 2;
        return(tempval);
}

uint16_t makeflagsword() {
        return(0xF000 + (uint16_t)cf + 2 + ((uint16_t)pf * 4) + ((uint16_t)af * 16) + ((uint16_t)zf * 64) \
        + ((uint16_t)sf * 128) + ((uint16_t)tf * 256) + ((uint16_t)ifl * 512) + ((uint16_t)df * 1024) + ((uint16_t)of * 2048));
}

void decodeflagsword(uint16_t value) {
        cf = value & 1;
        if (value & 4) pf = 1; else pf = 0;
        if (value & 16) af = 1; else af = 0;
        if (value & 64) zf = 1; else zf = 0;
        if (value & 128) sf = 1; else sf = 0;
        if (value & 256) tf = 1; else tf = 0;
        if (value & 512) ifl = 1; else ifl = 0;
        if (value & 1024) df = 1; else df = 0;
        if (value & 2048) of = 1; else of = 0;
}

void reset86() {
        uint16_t i, cnt, bitcount;
        segregs[regcs] = 0xFFFF;
        ip = 0x0000;
        regs.wordregs[regsp] = 0xFFFE;
        
        //generate parity lookup table
        for (i=0; i<256; i++) {
                bitcount = 0;
                for (cnt=0; cnt<8; cnt++)
                bitcount += ((i >> cnt) & 1);
                if (bitcount & 1) parity[i] = 0; else parity[i] = 1;
        }
}

uint16_t readrm16(uint8_t rmval) {
        if (mode < 3) {
                getea(rmval);
                return(read86(ea) + (read86(ea+1) << 8));
                } else {
                return(getreg16(rmval));
        }
}

uint8_t readrm8(uint8_t rmval) {
        if (mode < 3) {
                getea(rmval);
                return(read86(ea));
                } else {
                return(getreg8(rmval));
        }
}

void writerm16(uint8_t rmval, uint16_t value) {
        if (mode < 3) {
                getea(rmval);
                write86(ea, value);
                write86(ea+1, value >> 8);
                } else {
                putreg16(rmval, value);
        }
}

void writerm8(uint8_t rmval, uint8_t value) {
        if (mode < 3) {
                getea(rmval);
                write86(ea, value);
                } else {
                putreg8(rmval, value);
        }
}

uint8_t dolog = 0;
FILE *logout;

void intcall86(uint8_t intnum) {
	uint8_t insertresult;
	uint16_t cassbytes;
	uint16_t oldregax;
	if (dolog==1) fprintf(logout, "  Interrupt call to %02Xh AX = %04X\n", intnum, getreg16(regax));
	switch (intnum) {
		
		case 0x06:
		if (verbose) { sprintf(msg, "Illegal opcode: %02X @ %04X:%04X\n", opcode, savecs, saveip); print(msg); }
		break;
		case 0x10: //video services
		/*if ((regs.byteregs[regah] == 0x9) || (regs.byteregs[regah]==0xE)) {
			sprintf(msg, "%c", regs.byteregs[regal]); print(msg);
		}*/
		if ((regs.byteregs[regah]==0x00) || (regs.byteregs[regah]==0x10)) {
			oldregax = regs.wordregs[regax];
			vidinterrupt();
			regs.wordregs[regax] = oldregax;
			if (regs.byteregs[regah]==0x10) return;
			if (vidmode==9) return;
			//if ((regs.byteregs[regah]==0) && (regs.byteregs[regal]==0x9)) return;
			//vidmode = regs.byteregs[regal];
		}
		if (regs.byteregs[regah]==0x1A) {
			regs.byteregs[regal] = 0x1A;
			regs.byteregs[regbl] = 0x8;
			//sprintf(msg, "Display type request\n"); print(msg);
			return;
		}
		#if defined(CONSOLE)
		if (regs.byteregs[regah]==0xE) {
			sprintf(msg, "%c", regs.byteregs[regal]); print(msg);
		}
		#endif
		break; //return;
		case 0x13: //disk services
		//sprintf(msg, "Int 13h: AX = %04X    DX = %04X    CX=%04X    BX=%04X\n", regs.wordregs[regax], regs.wordregs[regdx], regs.wordregs[regcx], regs.wordregs[regbx]); print(msg);
		diskhandler();
		return;
		case 0x16: //keyboard (the BIOS handles it, but this is to wrap extended keystroke requests to normal functions)
		     if ((regs.byteregs[regah]>=0x10) && (regs.byteregs[regah]<=0x12)) regs.byteregs[regah] -= 0x10;
		     break;
		case 0x19: //bootstrap
		if (verbose) { sprintf(msg, "BOOTSTRAP!\n"); print(msg); }
		clocksafe = 1; doclocktick = 1; timerack = 1;
		if (bootdrive<255) {
			regs.byteregs[regdl] = bootdrive;
			readdisk(regs.byteregs[regdl], 0x07C0, 0x0000, 0, 1, 0, 1);
			segregs[regcs] = 0x0000; ip = 0x7C00;
	} else { segregs[regcs] = 0xF600; ip =0x0000; }
		return;
        case 0xFB:
             sprintf(msg, "FakeXMS driver called with function AH = %02X\n", regs.byteregs[regah]); print(msg);
             return;
		case 0xFC: //networking
		#if defined(NETWORKING_ENABLED)
		    nethandler();
        #endif
		return;
		default: break;
	}
	
	push(makeflagsword());
	push(segregs[regcs]);
	push(ip);
	segregs[regcs] = getmem16(0, (uint16_t)intnum*4+2);
	ip = getmem16(0, (uint16_t)intnum*4);
	ifl = 0;
	tf = 0;
}

extern SDL_AudioSpec wanted;
extern uint8_t buf[2][44100];
extern uint32_t bufpos;
float adlibenv[9], adlibdecay[9], adlibattack[9]; //, attacktable[16];
uint8_t adlibdidattack[9];
extern int8_t waveform[4][64], adlibstatus;
extern uint16_t adlibregmem[0xFF];
extern struct structadlibchan {
       uint16_t freq;
       float convfreq;
       uint8_t keyon;
       uint16_t octave;
       uint8_t wavesel;
} adlibch[9];
uint64_t adlibtimer[2];
extern FILE *audfile;
int32_t samplestep = 0;
int32_t ssourcecursample = 0;
#if defined(NETWORKING_ENABLED)
extern struct netstruct {
       uint8_t enabled;
       uint8_t canrecv;
       uint16_t pktlen;
} net;
#endif
uint64_t frametimer = 0, didwhen = 0, didticks = 0;
uint32_t makeupticks = 0;
extern float timercomp;
uint64_t timerticks = 0, realticks = 0;

FILE *opcodes_file = NULL;
FILE *asserts_file = NULL;
int cpu_count = 0;
#define MAX_CPU_COUNT = 100;

void exec86(uint32_t execloops) {
        uint32_t loopcount, tmpeax, tmpedx;
        uint8_t docontinue;
        static uint16_t firstip;

        static int print_dbg_opcodes = 1;

        if(print_dbg_opcodes) {
        	opcodes_file = fopen("opcodes.txt", "w");
        }
        
        if(print_dbg_opcodes) {
			asserts_file = fopen("asserts.csv", "w");
			fprintf(asserts_file, "cpu;opcode;ax;bx;cx;dx;sp;bp;si;di;es;ds;cs;ss;ip;sp\n");
        }


        for (loopcount=0; loopcount<execloops; loopcount++) {
                timing();
                if (ifl && (i8259.irr & (~i8259.imr))) intcall86(nextintr()); //get next interrupt from the i8259, if any
                reptype = 0; segoverride = 0;
                useseg = segregs[regds]; docontinue = 0;
                firstip = ip;
                while(!docontinue) {
                        segregs[regcs] = segregs[regcs] & 0xFFFF; ip = ip & 0xFFFF;
                        savecs = segregs[regcs]; saveip = ip;
                        opcode = getmem8(segregs[regcs], ip); StepIP(1);
                        
                        if(loopcount >= 100 && opcodes_file != NULL) {
                        	fclose(opcodes_file);
                        	print_dbg_opcodes = 0;
                        	opcodes_file = NULL;
                        	if(asserts_file != NULL) {
                        		fclose(asserts_file);
                        		asserts_file = NULL;
                        	}
                        }

                        switch (opcode) {
                                //segment prefix check
                                case 0x2E: //segment segregs[regcs]
                                useseg = segregs[regcs]; segoverride = 1; break;
                                case 0x3E: //segment segregs[regds]
                                useseg = segregs[regds]; segoverride = 1; break;
                                case 0x26: //segment segregs[reges]
                                useseg = segregs[reges]; segoverride = 1; break;
                                case 0x36: //segment segregs[regss]
                                useseg = segregs[regss]; segoverride = 1; break;
                                
                                //repetition prefix check
                                case 0xF3: //REP/REPE/REPZ
                                reptype = 1; break;
                                case 0xF2: //REPNE/REPNZ
                                reptype = 2; break;
                                default: docontinue = 1;
                        }
                }
                totalexec++;
                
                //sprintf(msg, "%04X:%04X - %s\n", savecs, saveip, oplist[opcode]); print(msg);
                int sawNewOpcode = 0;
                if (verbose) {
                	if(used_opcodes[opcode] == 0) {
                		//sprintf(msg, "%04X:%04X - %s\n", savecs, saveip, oplist[opcode]);
                		sprintf(msg, "%s\n", oplist[opcode]);
                		print(msg);
                		sawNewOpcode = 1;
                	}
                	used_opcodes[opcode] = 1;
                }
                switch (opcode) {
                        case 0x0: //00 ADD Eb Gb
                        modregrm();
                        oper1b = readrm8(rm); oper2b = getreg8(reg);
                        res8 = oper1b + oper2b;
                        flag_add8(oper1b, oper2b);
                        writerm8(rm, res8);
                        break;
                        case 0x1: //01 ADD Ev Gv
                        modregrm();
                        oper1 = readrm16(rm); oper2 = getreg16(reg);
                        res16 = oper1 + oper2;
                        flag_add16(oper1, oper2);
                        writerm16(rm, res16);
                        break;
                        case 0x2: //02 ADD Gb Eb
                        modregrm();
                        oper1b = getreg8(reg); oper2b = readrm8(rm);
                        res8 = oper1b + oper2b;
                        flag_add8(oper1b, oper2b);
                        putreg8(reg, res8);
                        break;
                        case 0x3: //03 ADD Gv Ev
                        modregrm();
                        oper1 = getreg16(reg); oper2 = readrm16(rm);
                        res16 = oper1 + oper2;
                        flag_add16(oper1, oper2);
                        putreg16(reg, res16);
                        break;
                        case 0x4: //04 ADD regs.byteregs[regal] Ib
                        oper1b = regs.byteregs[regal]; oper2b = getmem8(segregs[regcs], ip); StepIP(1);
                        res8 = oper1b + oper2b;
                        flag_add8(oper1b, oper2b);
                        regs.byteregs[regal] = res8;
                        break;
                        case 0x5: //05 ADD eAX Iv
                        oper1 = (regs.wordregs[regax]); oper2 = getmem16(segregs[regcs], ip); StepIP(2);
                        res16 = oper1 + oper2;
                        flag_add16(oper1, oper2);
                        regs.byteregs[regah] = res16 >> 8; regs.byteregs[regal] = res16 & 255;
                        break;
                        case 0x6: //06 PUSH segregs[reges]
                        push(segregs[reges]);
                        break;
                        case 0x7: //07 POP segregs[reges]
                        segregs[reges] = pop();
                        break;
                        case 0x8: //08 OR Eb Gb
                        modregrm();
                        oper1b = readrm8(rm); oper2b = getreg8(reg);
                        res8 = oper1b | oper2b;
                        flag_log8(res8);
                        writerm8(rm, res8);
                        break;
                        case 0x9: //09 OR Ev Gv
                        modregrm();
                        oper1 = readrm16(rm); oper2 = getreg16(reg);
                        res16 = oper1 | oper2;
                        flag_log16(res16);
                        writerm16(rm, res16);
                        break;
                        case 0xA: //0A OR Gb Eb
                        modregrm();
                        oper1b = getreg8(reg); oper2b = readrm8(rm);
                        res8 = oper1b | oper2b;
                        flag_log8(res8);
                        putreg8(reg, res8);
                        break;
                        case 0xB: //0B OR Gv Ev
                        modregrm();
                        oper1 = getreg16(reg); oper2 = readrm16(rm);
                        res16 = oper1 | oper2;
                        flag_log16(res16);
                        putreg16(reg, res16);
                        break;
                        case 0xC: //0C OR regs.byteregs[regal] Ib
                        oper1b = regs.byteregs[regal]; oper2b = getmem8(segregs[regcs], ip); StepIP(1);
                        res8 = oper1b | oper2b;
                        flag_log8(res8);
                        regs.byteregs[regal] = res8;
                        break;
                        case 0xD: //0D OR eAX Iv
                        oper1 = (regs.wordregs[regax]); oper2 = getmem16(segregs[regcs], ip); StepIP(2);
                        res16 = oper1 | oper2;
                        flag_log16(res16);
                        regs.byteregs[regah] = res16 >> 8; regs.byteregs[regal] = res16 & 255;
                        break;
                        case 0xE: //0E PUSH segregs[regcs]
                        push(segregs[regcs]);
                        break;
                        case 0x10: //10 ADC Eb Gb
                        modregrm();
                        oper1b = readrm8(rm); oper2b = getreg8(reg);
                        res8 = oper1b + oper2b + cf;
                        flag_adc8(oper1b, oper2b, cf);
                        writerm8(rm, res8);
                        break;
                        case 0x11: //11 ADC Ev Gv
                        modregrm();
                        oper1 = readrm16(rm); oper2 = getreg16(reg);
                        res16 = oper1 + oper2 + cf;
                        flag_adc16(oper1, oper2, cf);
                        writerm16(rm, res16);
                        break;
                        case 0x12: //12 ADC Gb Eb
                        modregrm();
                        oper1b = getreg8(reg); oper2b = readrm8(rm);
                        res8 = oper1b + oper2b + cf;
                        flag_adc8(oper1b, oper2b, cf);
                        putreg8(reg, res8);
                        break;
                        case 0x13: //13 ADC Gv Ev
                        modregrm();
                        oper1 = getreg16(reg); oper2 = readrm16(rm);
                        res16 = oper1 + oper2 + cf;
                        flag_adc16(oper1, oper2, cf);
                        putreg16(reg, res16);
                        break;
                        case 0x14: //14 ADC regs.byteregs[regal] Ib
                        oper1b = regs.byteregs[regal]; oper2b = getmem8(segregs[regcs], ip); StepIP(1);
                        res8 = oper1b + oper2b + cf;
                        flag_adc8(oper1b, oper2b, cf);
                        regs.byteregs[regal] = res8;
                        break;
                        case 0x15: //15 ADC eAX Iv
                        oper1 = (regs.wordregs[regax]); oper2 = getmem16(segregs[regcs], ip); StepIP(2);
                        res16 = oper1 + oper2 + cf;
                        flag_adc16(oper1, oper2, cf);
                        regs.byteregs[regah] = res16 >> 8; regs.byteregs[regal] = res16 & 255;
                        
                        break;
                        case 0x16: //16 PUSH segregs[regss]
                        push(segregs[regss]);
                        break;
                        case 0x17: //17 POP segregs[regss]
                        segregs[regss] = pop();
                        break;
                        case 0x18: //18 SBB Eb Gb
                        modregrm();
                        oper1b = readrm8(rm); oper2b = getreg8(reg);
                        res8 = oper1b - (oper2b + cf);
                        flag_sbb8(oper1b, oper2b, cf);
                        writerm8(rm, res8);
                        break;
                        case 0x19: //19 SBB Ev Gv
                        modregrm();
                        oper1 = readrm16(rm); oper2 = getreg16(reg);
                        res16 = oper1 - (oper2 + cf);
                        flag_sbb16(oper1, oper2, cf);
                        writerm16(rm, res16);
                        break;
                        case 0x1A: //1A SBB Gb Eb
                        modregrm();
                        oper1b = getreg8(reg); oper2b = readrm8(rm);
                        res8 = oper1b - (oper2b + cf);
                        flag_sbb8(oper1b, oper2b, cf);
                        putreg8(reg, res8);
                        break;
                        case 0x1B: //1B SBB Gv Ev
                        modregrm();
                        oper1 = getreg16(reg); oper2 = readrm16(rm);
                        res16 = oper1 - (oper2 + cf);
                        flag_sbb16(oper1, oper2, cf);
                        putreg16(reg, res16);
                        break;
                        case 0x1C: //1C SBB regs.byteregs[regal] Ib;
                        oper1b = regs.byteregs[regal]; oper2b = getmem8(segregs[regcs], ip); StepIP(1);
                        res8 = oper1b - (oper2b + cf);
                        flag_sbb8(oper1b, oper2b, cf);
                        regs.byteregs[regal] = res8;
                        break;
                        case 0x1D: //1D SBB eAX Iv
                        oper1 = (regs.wordregs[regax]); oper2 = getmem16(segregs[regcs], ip); StepIP(2);
                        res16 = oper1 - (oper2 + cf);
                        flag_sbb16(oper1, oper2, cf);
                        regs.byteregs[regah] = res16 >> 8; regs.byteregs[regal] = res16 & 255;
                        break;
                        case 0x1E: //1E PUSH segregs[regds]
                        push(segregs[regds]);
                        break;
                        case 0x1F: //1F POP segregs[regds]
                        segregs[regds] = pop();
                        break;
                        case 0x20: //20 AND Eb Gb
                        modregrm();
                        oper1b = readrm8(rm); oper2b = getreg8(reg);
                        res8 = oper1b & oper2b;
                        flag_log8(res8);
                        writerm8(rm, res8);
                        break;
                        case 0x21: //21 AND Ev Gv
                        modregrm();
                        oper1 = readrm16(rm); oper2 = getreg16(reg);
                        res16 = oper1 & oper2;
                        flag_log16(res16);
                        writerm16(rm, res16);
                        break;
                        case 0x22: //22 AND Gb Eb
                        modregrm();
                        oper1b = getreg8(reg); oper2b = readrm8(rm);
                        res8 = oper1b & oper2b;
                        flag_log8(res8);
                        putreg8(reg, res8);
                        break;
                        case 0x23: //23 AND Gv Ev
                        modregrm();
                        oper1 = getreg16(reg); oper2 = readrm16(rm);
                        res16 = oper1 & oper2;
                        flag_log16(res16);
                        putreg16(reg, res16);
                        break;
                        case 0x24: //24 AND regs.byteregs[regal] Ib
                        oper1b = regs.byteregs[regal]; oper2b = getmem8(segregs[regcs], ip); StepIP(1);
                        res8 = oper1b & oper2b;
                        flag_log8(res8);
                        regs.byteregs[regal] = res8;
                        break;
                        case 0x25: //25 AND eAX Iv
                        oper1 = (regs.wordregs[regax]); oper2 = getmem16(segregs[regcs], ip); StepIP(2);
                        res16 = oper1 & oper2;
                        flag_log16(res16);
                        regs.byteregs[regah] = res16 >> 8; regs.byteregs[regal] = res16 & 255;
                        break;
                        case 0x27: //27 DAA
                        if (((regs.byteregs[regal] & 0xF) > 9) || (af==1)) {
                                oper1 = regs.byteregs[regal] + 6;
                                regs.byteregs[regal] = oper1 & 255;
                                if (oper1 & 0xFF00) cf = 1; else cf = 0;
                                af = 1;
                        } else af = 0;
                        if (((regs.byteregs[regal] & 0xF0) > 0x90) || (cf==1)) {
                                regs.byteregs[regal] = regs.byteregs[regal] + 0x60;
                                cf = 1;
                        } else cf = 0;
                        regs.byteregs[regal] = regs.byteregs[regal] & 255;
                        flag_szp8(regs.byteregs[regal]);
                        break;
                        case 0x28: //28 SUB Eb Gb
                        modregrm();
                        oper1b = readrm8(rm); oper2b = getreg8(reg);
                        res8 = oper1b - oper2b;
                        flag_sub8(oper1b, oper2b);
                        writerm8(rm, res8);
                        break;
                        case 0x29: //29 SUB Ev Gv
                        modregrm();
                        oper1 = readrm16(rm); oper2 = getreg16(reg);
                        res16 = oper1 - oper2;
                        flag_sub16(oper1, oper2);
                        writerm16(rm, res16);
                        break;
                        case 0x2A: //2A SUB Gb Eb
                        modregrm();
                        oper1b = getreg8(reg); oper2b = readrm8(rm);
                        res8 = oper1b - oper2b;
                        flag_sub8(oper1b, oper2b);
                        putreg8(reg, res8);
                        break;
                        case 0x2B: //2B SUB Gv Ev
                        modregrm();
                        oper1 = getreg16(reg); oper2 = readrm16(rm);
                        res16 = oper1 - oper2;
                        flag_sub16(oper1, oper2);
                        putreg16(reg, res16);
                        break;
                        case 0x2C: //2C SUB regs.byteregs[regal] Ib
                        oper1b = regs.byteregs[regal]; oper2b = getmem8(segregs[regcs], ip); StepIP(1);
                        res8 = oper1b - oper2b;
                        flag_sub8(oper1b, oper2b);
                        regs.byteregs[regal] = res8;
                        break;
                        case 0x2D: //2D SUB eAX Iv
                        oper1 = (regs.wordregs[regax]); oper2 = getmem16(segregs[regcs], ip); StepIP(2);
                        res16 = oper1 - oper2;
                        flag_sub16(oper1, oper2);
                        regs.byteregs[regah] = res16 >> 8; regs.byteregs[regal] = res16 & 255;
                        break;
                        case 0x2F: //2F DAS
                        if (((regs.byteregs[regal] & 15) > 9) || (af==1)) {
                                oper1 = regs.byteregs[regal] - 6;
                                regs.byteregs[regal] = oper1 & 255;
                                if (oper1 & 0xFF00) cf = 1; else cf = 0;
                                af = 1;
                        } else af = 0;
                        if (((regs.byteregs[regal] & 0xF0) > 0x90) || (cf==1)) {
                                regs.byteregs[regal] = regs.byteregs[regal] - 0x60;
                                cf = 1;
                        } else cf = 0;
                        flag_szp8(regs.byteregs[regal]);
                        break;
                        case 0x30: //30 XOR Eb Gb
                        modregrm();
                        oper1b = readrm8(rm); oper2b = getreg8(reg);
                        res8 = oper1b ^ oper2b;
                        flag_log8(res8);
                        writerm8(rm, res8);
                        break;
                        case 0x31: //31 XOR Ev Gv
                        modregrm();
                        oper1 = readrm16(rm); oper2 = getreg16(reg);
                        res16 = oper1 ^ oper2;
                        flag_log16(res16);
                        writerm16(rm, res16);
                        break;
                        case 0x32: //32 XOR Gb Eb
                        modregrm();
                        oper1b = getreg8(reg); oper2b = readrm8(rm);
                        res8 = oper1b ^ oper2b;
                        flag_log8(res8);
                        putreg8(reg, res8);
                        break;
                        case 0x33: //33 XOR Gv Ev
                        modregrm();
                        oper1 = getreg16(reg); oper2 = readrm16(rm);
                        res16 = oper1 ^ oper2;
                        flag_log16(res16);
                        putreg16(reg, res16);
                        break;
                        case 0x34: //34 XOR regs.byteregs[regal] Ib
                        oper1b = regs.byteregs[regal]; oper2b = getmem8(segregs[regcs], ip); StepIP(1);
                        res8 = oper1b ^ oper2b;
                        flag_log8(res8);
                        regs.byteregs[regal] = res8;
                        break;
                        case 0x35: //35 XOR eAX Iv
                        oper1 = (regs.wordregs[regax]); oper2 = getmem16(segregs[regcs], ip); StepIP(2);
                        res16 = oper1 ^ oper2;
                        flag_log16(res16);
                        regs.byteregs[regah] = res16 >> 8; regs.byteregs[regal] = res16 & 255;
                        break;
                        case 0x37: //37 AAA ASCII
                        if (((regs.byteregs[regal] & 0xF) > 9) || (af==1)) {
                                regs.byteregs[regal] = regs.byteregs[regal] + 6;
                                regs.byteregs[regah] = regs.byteregs[regah] + 1;
                                af = 1;
                                cf = 1;
                                } else {
                                af = 0;
                                cf = 0;
                        }
                        regs.byteregs[regal] = regs.byteregs[regal] & 0xF;
                        break;
                        case 0x38: //38 CMP Eb Gb
                        modregrm();
                        oper1b = readrm8(rm); oper2b = getreg8(reg);
                        flag_sub8(oper1b, oper2b);
                        break;
                        case 0x39: //39 CMP Ev Gv
                        modregrm();
                        oper1 = readrm16(rm); oper2 = getreg16(reg);
                        flag_sub16(oper1, oper2);
                        break;
                        case 0x3A: //3A CMP Gb Eb
                        modregrm();
                        oper1b = getreg8(reg); oper2b = readrm8(rm);
                        flag_sub8(oper1b, oper2b);
                        break;
                        case 0x3B: //3B CMP Gv Ev
                        modregrm();
                        oper1 = getreg16(reg); oper2 = readrm16(rm);
                        flag_sub16(oper1, oper2);
                        break;
                        case 0x3C: //3C CMP regs.byteregs[regal] Ib
                        oper1b = regs.byteregs[regal]; oper2b = getmem8(segregs[regcs], ip); StepIP(1);
                        flag_sub8(oper1b, oper2b);
                        break;
                        case 0x3D: //3D CMP eAX Iv
                        oper1 = (regs.wordregs[regax]); oper2 = getmem16(segregs[regcs], ip); StepIP(2);
                        flag_sub16(oper1, oper2);
                        break;
                        case 0x3F: //3F AAS ASCII
                        if (((regs.byteregs[regal] & 0xF) > 9) || (af==1)) {
                                regs.byteregs[regal] = regs.byteregs[regal] - 6;
                                regs.byteregs[regah] = regs.byteregs[regah] - 1;
                                af = 1;
                                cf = 1;
                                } else {
                                af = 0;
                                cf = 0;
                        }
                        regs.byteregs[regal] = regs.byteregs[regal] & 0xF;
                        break;
                        case 0x40: //40 INC eAX
                        oldcf = cf;
                        oper1 = (regs.wordregs[regax]); oper2 = 1;
                        res16 = oper1 + oper2;
                        flag_add16(oper1, oper2);
                        cf = oldcf;
                        regs.byteregs[regah] = res16 >> 8; regs.byteregs[regal] = res16 & 255;
                        break;
                        case 0x41: //41 INC eCX
                        oldcf = cf;
                        oper1 = (regs.wordregs[regcx]); oper2 = 1;
                        res16 = oper1 + oper2;
                        flag_add16(oper1, oper2);
                        cf = oldcf;
                        putreg16(regcx, res16);
                        break;
                        case 0x42: //42 INC eDX
                        oldcf = cf;
                        oper1 = (regs.wordregs[regdx]); oper2 = 1;
                        res16 = oper1 + oper2;
                        flag_add16(oper1, oper2);
                        cf = oldcf;
                        putreg16(regdx, res16);
                        break;
                        case 0x43: //43 INC eBX
                        oldcf = cf;
                        oper1 = (regs.wordregs[regbx]); oper2 = 1;
                        res16 = oper1 + oper2;
                        flag_add16(oper1, oper2);
                        cf = oldcf;
                        putreg16(regbx, res16);
                        break;
                        case 0x44: //44 INC eSP
                        oldcf = cf;
                        oper1 = regs.wordregs[regsp]; oper2 = 1;
                        res16 = oper1 + oper2;
                        flag_add16(oper1, oper2);
                        cf = oldcf;
                        regs.wordregs[regsp] = res16;
                        break;
                        case 0x45: //45 INC eBP
                        oldcf = cf;
                        oper1 = regs.wordregs[regbp]; oper2 = 1;
                        res16 = oper1 + oper2;
                        flag_add16(oper1, oper2);
                        cf = oldcf;
                        regs.wordregs[regbp] = res16;
                        break;
                        case 0x46: //46 INC eSI
                        oldcf = cf;
                        oper1 = regs.wordregs[regsi]; oper2 = 1;
                        res16 = oper1 + oper2;
                        flag_add16(oper1, oper2);
                        cf = oldcf;
                        regs.wordregs[regsi] = res16;
                        break;
                        case 0x47: //47 INC eDI
                        oldcf = cf;
                        oper1 = regs.wordregs[regdi]; oper2 = 1;
                        res16 = oper1 + oper2;
                        flag_add16(oper1, oper2);
                        cf = oldcf;
                        regs.wordregs[regdi] = res16;
                        break;
                        case 0x48: //48 DEC eAX
                        oldcf = cf;
                        oper1 = (regs.wordregs[regax]); oper2 = 1;
                        res16 = oper1 - oper2;
                        flag_sub16(oper1, oper2);
                        cf = oldcf;
                        regs.byteregs[regah] = res16 >> 8; regs.byteregs[regal] = res16 & 255;
                        break;
                        case 0x49: //49 DEC eCX
                        oldcf = cf;
                        oper1 = (regs.wordregs[regcx]); oper2 = 1;
                        res16 = oper1 - oper2;
                        flag_sub16(oper1, oper2);
                        cf = oldcf;
                        putreg16(regcx, res16);
                        break;
                        case 0x4A: //4A DEC eDX
                        oldcf = cf;
                        oper1 = (regs.wordregs[regdx]); oper2 = 1;
                        res16 = oper1 - oper2;
                        flag_sub16(oper1, oper2);
                        cf = oldcf;
                        putreg16(regdx, res16);
                        break;
                        case 0x4B: //4B DEC eBX
                        oldcf = cf;
                        oper1 = (regs.wordregs[regbx]); oper2 = 1;
                        res16 = oper1 - oper2;
                        flag_sub16(oper1, oper2);
                        cf = oldcf;
                        putreg16(regbx, res16);
                        break;
                        case 0x4C: //4C DEC eSP
                        oldcf = cf;
                        oper1 = regs.wordregs[regsp]; oper2 = 1;
                        res16 = oper1 - oper2;
                        flag_sub16(oper1, oper2);
                        cf = oldcf;
                        regs.wordregs[regsp] = res16;
                        break;
                        case 0x4D: //4D DEC eBP
                        oldcf = cf;
                        oper1 = regs.wordregs[regbp]; oper2 = 1;
                        res16 = oper1 - oper2;
                        flag_sub16(oper1, oper2);
                        cf = oldcf;
                        regs.wordregs[regbp] = res16;
                        break;
                        case 0x4E: //4E DEC eSI
                        oldcf = cf;
                        oper1 = regs.wordregs[regsi]; oper2 = 1;
                        res16 = oper1 - oper2;
                        flag_sub16(oper1, oper2);
                        cf = oldcf;
                        regs.wordregs[regsi] = res16;
                        break;
                        case 0x4F: //4F DEC eDI
                        oldcf = cf;
                        oper1 = regs.wordregs[regdi]; oper2 = 1;
                        res16 = oper1 - oper2;
                        flag_sub16(oper1, oper2);
                        cf = oldcf;
                        regs.wordregs[regdi] = res16;
                        break;
                        case 0x50: //50 PUSH eAX
                        push (regs.wordregs[regax]);
                        break;
                        case 0x51: //51 PUSH eCX
                        push (regs.wordregs[regcx]);
                        break;
                        case 0x52: //52 PUSH eDX
                        push (regs.wordregs[regdx]);
                        break;
                        case 0x53: //53 PUSH eBX
                        push (regs.wordregs[regbx]);
                        break;
                        case 0x54: //54 PUSH eSP
                        push(regs.wordregs[regsp]);
                        break;
                        case 0x55: //55 PUSH eBP
                        push(regs.wordregs[regbp]);
                        break;
                        case 0x56: //56 PUSH eSI
                        push(regs.wordregs[regsi]);
                        break;
                        case 0x57: //57 PUSH eDI
                        push(regs.wordregs[regdi]);
                        break;
                        case 0x58: //58 POP eAX
                        res16 = pop();
                        regs.byteregs[regah] = res16 >> 8; regs.byteregs[regal] = res16 & 255;
                        break;
                        case 0x59: //59 POP eCX
                        res16 = pop();
                        regs.byteregs[regch] = res16 >> 8; regs.byteregs[regcl] = res16 & 255;
                        break;
                        case 0x5A: //5A POP eDX
                        res16 = pop();
                        regs.byteregs[regdh] = res16 >> 8; regs.byteregs[regdl] = res16 & 255;
                        break;
                        case 0x5B: //5B POP eBX
                        res16 = pop();
                        regs.byteregs[regbh] = res16 >> 8; regs.byteregs[regbl] = res16 & 255;
                        break;
                        case 0x5C: //5C POP eSP
                        regs.wordregs[regsp] = getmem16(segregs[regss], regs.wordregs[regsp]);
                        break;
                        case 0x5D: //5D POP eBP
                        regs.wordregs[regbp] = pop();
                        break;
                        case 0x5E: //5E POP eSI
                        regs.wordregs[regsi] = pop();
                        break;
                        case 0x5F: //5F POP eDI
                        regs.wordregs[regdi] = pop();
                        break;
                        case 0x60: //60 PUSHA (80186+)
                        oldsp = regs.wordregs[regsp];
                        push (regs.wordregs[regax]);
                        push (regs.wordregs[regcx]);
                        push (regs.wordregs[regdx]);
                        push (regs.wordregs[regbx]);
                        push(oldsp); push(regs.wordregs[regbp]); push(regs.wordregs[regsi]); push(regs.wordregs[regdi]);
                        break;
                        case 0x61: //61 POPA (80186+)
                        regs.wordregs[regdi] = pop(); regs.wordregs[regsi] = pop(); regs.wordregs[regbp] = pop(); dummy = pop();
                        putreg16(regbx, pop()); putreg16(regdx, pop()); putreg16(regcx, pop()); putreg16(regax, pop());
                        
                        break;
                        case 0x68: //68 PUSH Iv (80186+)
                        push(getmem16(segregs[regcs], ip)); StepIP(2);
                        
                        break;
                        case 0x69: //69 IMUL Ev Iv (80186+)
                        modregrm();
                        temp1 = readrm16(rm);
                        temp2 = getmem16(segregs[regcs], ip); StepIP(2);
                        if ((temp1 & 0x8000) == 0x8000) temp1 = temp1 | 0xFFFF0000;
                        if ((temp2 & 0x8000) == 0x8000) temp2 = temp2 | 0xFFFF0000;
                        temp3 = (temp1 * temp2) & 0xFFFFFFFF;
                        putreg16(regax, temp3 & 0xFFFF);
                        putreg16(regdx, temp3 >> 16);
                        if (regs.wordregs[regdx]) { cf = 1; of = 1; } else { cf = 0; of = 0; }
                        
                        break;
                        case 0x6A: //6A PUSH Ib (80186+)
                        push(getmem8(segregs[regcs], ip)); StepIP(1);
                        
                        break;
                        case 0x6B: //6B IMUL Eb Ib (80186+)
                        modregrm();
                        oper1 = signext(readrm8(rm));
                        temp1 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        temp2 = oper1;
                        if ((temp1 & 0x80) == 0x80) temp1 = temp1 | 0xFFFFFF00;
                        if ((temp2 & 0x80) == 0x80) temp2 = temp2 | 0xFFFFFF00;
                        temp3 = (temp1 * temp2) & 0xFFFF;
                        putreg16(regax, temp3);
                        if (regs.byteregs[regah]) { cf = 1; of = 1; } else { cf = 0; of = 0; }
                        
                        break;
                        case 0x6C ... 0x6F: //80186 port operations, just act as if they//re NOPs for now...
                        StepIP(1); //they have a modregrm(); byte we must skip... i may properly emulate these later.
                        break;
                        case 0x70: //70 JO Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (of) ip = ip + temp16;
                        
                        break;
                        case 0x71: //71 JNO Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (!of) ip = ip + temp16;
                        
                        break;
                        case 0x72: //72 JB Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (cf) ip = ip + temp16;
                        
                        break;
                        case 0x73: //73 JNB Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (!cf) ip = ip + temp16;
                        
                        break;
                        case 0x74: //74 JZ Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (zf) ip = ip + temp16;
                        
                        break;
                        case 0x75: //75 JNZ Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (!zf) ip = ip + temp16;
                        
                        break;
                        case 0x76: //76 JBE Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (cf || zf) ip = ip + temp16;
                        
                        break;
                        case 0x77: //77 JA Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (!cf && !zf) ip = ip + temp16;
                        
                        break;
                        case 0x78: //78 JS Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (sf) ip = ip + temp16;
                        
                        break;
                        case 0x79: //79 JNS Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (!sf) ip = ip + temp16;
                        
                        break;
                        case 0x7A: //7A JPE Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (pf) ip = ip + temp16;
                        
                        break;
                        case 0x7B: //7B JPO Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (!pf) ip = ip + temp16;
                        
                        break;
                        case 0x7C: //7C JL Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (sf != of) ip = ip + temp16;
                        
                        break;
                        case 0x7D: //7D JGE Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (sf == of) ip = ip + temp16;
                        
                        break;
                        case 0x7E: //7E JLE Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if ((sf != of) || zf) ip = ip + temp16;
                        
                        break;
                        case 0x7F: //7F JG Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (!zf && (sf == of)) ip = ip + temp16;
                        
                        break;
                        case 0x80: case 0x82: //80/82 GRP1 Eb Ib
                        modregrm();
                        oper1b = readrm8(rm);
                        oper2b = getmem8(segregs[regcs], ip); StepIP(1);
                        switch (reg) {
                                case 0: op_add8(); break;
                                case 1: op_or8(); break;
                                case 2: op_adc8(); break;
                                case 3: op_sbb8(); break;
                                case 4: op_and8(); break;
                                case 5: op_sub8(); break;
                                case 6: op_xor8(); break;
                                case 7: flag_sub8(oper1b, oper2b); break;
                                default: break; //to avoid compiler warnings
                        }
                        if (reg < 7) writerm8(rm, res8);
                        break;
                        case 0x81: //81 GRP1 Ev Iv
                        case 0x83: //83 GRP1 Ev Ib
                        modregrm();
                        oper1 = readrm16(rm);
                        if (opcode == 0x81) {
                                oper2 = getmem16(segregs[regcs], ip); StepIP(2);
                                } else {
                                oper2 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        }
                        switch (reg) {
                                case 0: op_add16(); break;
                                case 1: op_or16(); break;
                                case 2: op_adc16(); break;
                                case 3: op_sbb16(); break;
                                case 4: op_and16(); break;
                                case 5: op_sub16(); break;
                                case 6: op_xor16(); break;
                                case 7: flag_sub16(oper1, oper2); break;
                                default: break; //to avoid compiler warnings
                        }
                        if (reg < 7) writerm16(rm, res16);
                        break;
                        break;
                        case 0x84: //84 TEST Gb Eb
                        modregrm();
                        oper1b = getreg8(reg); oper2b = readrm8(rm);
                        flag_log8(oper1b & oper2b);
                        break;
                        case 0x85: //85 TEST Gv Ev
                        modregrm();
                        oper1 = getreg16(reg); oper2 = readrm16(rm);
                        flag_log16(oper1 & oper2);
                        break;
                        case 0x86: //86 XCHG Gb Eb
                        modregrm();
                        oper1b = getreg8(reg);
                        putreg8(reg, readrm8(rm));
                        writerm8(rm, oper1b);
                        break;
                        case 0x87: //87 XCHG Gv Ev
                        modregrm();
                        oper1 = getreg16(reg);
                        putreg16(reg, readrm16(rm));
                        writerm16(rm, oper1);
                        break;
                        case 0x88: //88 MOV Eb Gb
                        modregrm();
                        writerm8(rm, getreg8(reg));
                        break;
                        case 0x89: //89 MOV Ev Gv
                        modregrm();
                        writerm16(rm, getreg16(reg));
                        break;
                        case 0x8A: //8A MOV Gb Eb
                        modregrm();
                        putreg8(reg, readrm8(rm));
                        break;
                        case 0x8B: //8B MOV Gv Ev
                        modregrm();
                        putreg16(reg, readrm16(rm));
                        break;
                        case 0x8C: //8C MOV Ew Sw
                        modregrm();
                        writerm16(rm, getsegreg(reg));
                        break;
                        case 0x8D: //8D LEA Gv M
                        modregrm();
                        getea(rm);
                        putreg16(reg, ea - useseg * 16);
                        break;
                        case 0x8E: //8E MOV Sw Ew
                        modregrm();
                        putsegreg(reg, readrm16(rm));
                        break;
                        case 0x8F: //8F POP Ev
                        modregrm();
                        writerm16(rm, pop());
                        break;
                        case 0x90: //90 NOP
                        break;
                        case 0x91: //91 XCHG eCX eAX
                        oper1b = regs.byteregs[regch];
                        oper2b = regs.byteregs[regcl];
                        regs.byteregs[regch] = regs.byteregs[regah];
                        regs.byteregs[regcl] = regs.byteregs[regal];
                        regs.byteregs[regah] = oper1b;
                        regs.byteregs[regal] = oper2b;
                        break;
                        case 0x92: //92 XCHG eDX eAX
                        oper1b = regs.byteregs[regdh];
                        oper2b = regs.byteregs[regdl];
                        regs.byteregs[regdh] = regs.byteregs[regah];
                        regs.byteregs[regdl] = regs.byteregs[regal];
                        regs.byteregs[regah] = oper1b;
                        regs.byteregs[regal] = oper2b;
                        break;
                        case 0x93: //93 XCHG eBX eAX
                        oper1b = regs.byteregs[regbh];
                        oper2b = regs.byteregs[regbl];
                        regs.byteregs[regbh] = regs.byteregs[regah];
                        regs.byteregs[regbl] = regs.byteregs[regal];
                        regs.byteregs[regah] = oper1b;
                        regs.byteregs[regal] = oper2b;
                        break;
                        case 0x94: //94 XCHG eSP eAX
                        oper1 = regs.wordregs[regsp];
                        regs.wordregs[regsp] = (regs.wordregs[regax]);
                        regs.byteregs[regah] = oper1 >> 8; regs.byteregs[regal] = oper1 & 255;
                        break;
                        case 0x95: //95 XCHG eBP eAX
                        oper1 = regs.wordregs[regbp];
                        regs.wordregs[regbp] = (regs.wordregs[regax]);
                        regs.byteregs[regah] = oper1 >> 8; regs.byteregs[regal] = oper1 & 255;
                        break;
                        case 0x96: //96 XCHG eSI eAX
                        oper1 = regs.wordregs[regsi];
                        regs.wordregs[regsi] = (regs.wordregs[regax]);
                        regs.byteregs[regah] = oper1 >> 8; regs.byteregs[regal] = oper1 & 255;
                        break;
                        case 0x97: //97 XCHG eDI eAX
                        oper1 = regs.wordregs[regdi];
                        regs.wordregs[regdi] = (regs.wordregs[regax]);
                        regs.byteregs[regah] = oper1 >> 8; regs.byteregs[regal] = oper1 & 255;
                        break;
                        case 0x98: //98 CBW
                        if ((regs.byteregs[regal] & 0x80) == 0x80) regs.byteregs[regah] = 0xFF; else regs.byteregs[regah] = 0;
                        break;
                        case 0x99: //99 CWD
                        if ((regs.byteregs[regah] & 0x80) == 0x80) putreg16(regdx, 0xFFFF); else putreg16(regdx, 0);
                        break;
                        case 0x9A: //9A CALL Ap
                        oper1 = getmem16(segregs[regcs], ip); StepIP(2);
                        oper2 = getmem16(segregs[regcs], ip); StepIP(2);
                        push(segregs[regcs]); push(ip); ip = oper1; segregs[regcs] = oper2;
                        break;
                        case 0x9B: //9B WAIT
                        break;
                        case 0x9C: //9C PUSHF
                        push(makeflagsword() | 0xF800);
                        break;
                        case 0x9D: //9D POPF
                        decodeflagsword(pop());
                        break;
                        case 0x9E: //9E SAHF
                        decodeflagsword ((makeflagsword() & 0xFF00) | regs.byteregs[regah]);
                        break;
                        case 0x9F: //9F LAHF
                        regs.byteregs[regah] = makeflagsword() & 0xFF;
                        break;
                        case 0xA0: //A0 MOV regs.byteregs[regal] Ob
                        regs.byteregs[regal] = getmem8(useseg, getmem16(segregs[regcs], ip)); StepIP(2);
                        break;
                        case 0xA1: //A1 MOV eAX Ov
                        oper1 = getmem16(useseg, getmem16(segregs[regcs], ip)); StepIP(2);
                        regs.byteregs[regah] = oper1 >> 8; regs.byteregs[regal] = oper1 & 255;
                        break;
                        case 0xA2: //A2 MOV Ob regs.byteregs[regal]
                        putmem8(useseg, getmem16(segregs[regcs], ip), regs.byteregs[regal]); StepIP(2);
                        break;
                        case 0xA3: //A3 MOV Ov eAX
                        putmem16(useseg, getmem16(segregs[regcs], ip), (regs.wordregs[regax])); StepIP(2);
                        break;
                        case 0xA4: //A4 MOVSB
                        //sprintf(msg, "MOVSB"); print(msg);
                        //while(1) {
                                if (reptype && (regs.wordregs[regcx]==0)) break;
                                putmem8(segregs[reges], regs.wordregs[regdi], getmem8(useseg, regs.wordregs[regsi]));
                                //sprintf(msg, "%c", getmem8(useseg, regs.wordregs[regsi])); print(msg);
                                if (df) { regs.wordregs[regsi] = regs.wordregs[regsi] - 1; regs.wordregs[regdi] = regs.wordregs[regdi] - 1; } else { regs.wordregs[regsi] = regs.wordregs[regsi] + 1; regs.wordregs[regdi] = regs.wordregs[regdi] + 1; }
                                if (reptype) regs.wordregs[regcx]--; //putreg16(regcx, (regs.wordregs[regcx]) - 1);
                                totalexec++; loopcount++;
                                timing();
                                if (!reptype) break;
                                ip = firstip;
                                //if (loopcount>=execloops) { ip = firstip; return; }
                                //if (ifl && (i8259.irr & (~i8259.imr))) { ip = firstip; break; } //save IP and stop loop execution if an interrupt is requested
                        //}
                        //sprintf(msg, "\n"); print(msg);
                        break;
                        case 0xA5: //A5 MOVSW
                        //sprintf(msg, "MOVSW"); print(msg);
                        //while(1) {
                                if (reptype && (regs.wordregs[regcx]==0)) break;
                                putmem16(segregs[reges], regs.wordregs[regdi], getmem16(useseg, regs.wordregs[regsi]));
                                //sprintf(msg, "%c%c", getmem8(segregs[reges], regs.wordregs[regdi]), getmem8(segregs[reges], regs.wordregs[regdi+1])); print(msg);
                                if (df) { regs.wordregs[regsi] = regs.wordregs[regsi] - 2; regs.wordregs[regdi] = regs.wordregs[regdi] - 2; } else { regs.wordregs[regsi] = regs.wordregs[regsi] + 2; regs.wordregs[regdi] = regs.wordregs[regdi] + 2; }
                                if (reptype) regs.wordregs[regcx]--; //putreg16(regcx, (regs.wordregs[regcx]) - 1);
                                totalexec++; loopcount++;
                                timing();
                                if (!reptype) break;
                                ip = firstip;
                                //if (loopcount>=execloops) { ip = firstip; return; }
                                //if (ifl && (i8259.irr & (~i8259.imr))) { ip = firstip; break; } //save IP and stop loop execution if an interrupt is requested
                        //}
                        //sprintf(msg, "\n"); print(msg);
                        break;
                        case 0xA6: //A6 CMPSB
                        //while(1) {
                                if (reptype && (regs.wordregs[regcx]==0)) break;
                                oper1b = getmem8(useseg, regs.wordregs[regsi]); oper2b = getmem8(segregs[reges], regs.wordregs[regdi]);
                                if (df) { regs.wordregs[regsi] = regs.wordregs[regsi] - 1; regs.wordregs[regdi] = regs.wordregs[regdi] - 1; } else { regs.wordregs[regsi] = regs.wordregs[regsi] + 1; regs.wordregs[regdi] = regs.wordregs[regdi] + 1; }
                                flag_sub8(oper1b, oper2b);
                                if (reptype) regs.wordregs[regcx]--; //putreg16(regcx, (regs.wordregs[regcx]) - 1);
                                if ((reptype == 1) && !zf) break;
                                else if ((reptype == 2) && (zf == 1)) break;
                                totalexec++; loopcount++;
                                timing();
                                if (!reptype) break;
                                ip = firstip;
                                //if (loopcount>=execloops) { ip = firstip; return; }
                                //if (ifl && (i8259.irr & (~i8259.imr))) { ip = firstip; break; } //save IP and stop loop execution if an interrupt is requested
                        //}
                        break;
                        case 0xA7: //A7 CMPSW
                        //while(1) {
                                if (reptype && (regs.wordregs[regcx]==0)) break;
                                oper1 = getmem16(useseg, regs.wordregs[regsi]); oper2 = getmem16(segregs[reges], regs.wordregs[regdi]);
                                if (df) { regs.wordregs[regsi] = regs.wordregs[regsi] - 2; regs.wordregs[regdi] = regs.wordregs[regdi] - 2; } else { regs.wordregs[regsi] = regs.wordregs[regsi] + 2; regs.wordregs[regdi] = regs.wordregs[regdi] + 2; }
                                flag_sub16(oper1, oper2);
                                if (reptype) regs.wordregs[regcx]--; //putreg16(regcx, (regs.wordregs[regcx]) - 1);
                                if ((reptype == 1) && !zf) break;
                                if ((reptype == 2) && (zf == 1)) break;
                                totalexec++; loopcount++;
                                timing();
                                if (!reptype) break;
                                ip = firstip;
                                //if (loopcount>=execloops) { ip = firstip; return; }
                                //if (ifl && (i8259.irr & (~i8259.imr))) { ip = firstip; break; } //save IP and stop loop execution if an interrupt is requested
                        //}
                        break;
                        case 0xA8: //A8 TEST regs.byteregs[regal] Ib
                        oper1b = regs.byteregs[regal]; oper2b = getmem8(segregs[regcs], ip); StepIP(1);
                        flag_log8(oper1b & oper2b);
                        break;
                        case 0xA9: //A9 TEST eAX Iv
                        oper1 = (regs.wordregs[regax]); oper2 = getmem16(segregs[regcs], ip); StepIP(2);
                        flag_log16(oper1 & oper2);
                        break;
                        case 0xAA: //AA STOSB
                        //while(1) {
                                if (reptype && (regs.wordregs[regcx]==0)) break;
                                putmem8(segregs[reges], regs.wordregs[regdi], regs.byteregs[regal]);
                                if (df) regs.wordregs[regdi] = regs.wordregs[regdi] - 1; else regs.wordregs[regdi] = regs.wordregs[regdi] + 1;
                                if (reptype) regs.wordregs[regcx]--; //putreg16(regcx, (regs.wordregs[regcx]) - 1);
                                totalexec++; loopcount++;
                                timing();
                                if (!reptype) break;
                                ip = firstip;
                                //if (loopcount>=execloops) { ip = firstip; return; }
                                //if (ifl && (i8259.irr & (~i8259.imr))) { ip = firstip; break; } //save IP and stop loop execution if an interrupt is requested
                        //}
                        break;
                        case 0xAB: //AB STOSW
                        //while(1) {
                                if (reptype && (regs.wordregs[regcx]==0)) break;
                                putmem16(segregs[reges], regs.wordregs[regdi], (regs.wordregs[regax]));
                                if (df) regs.wordregs[regdi] = regs.wordregs[regdi] - 2; else regs.wordregs[regdi] = regs.wordregs[regdi] + 2;
                                if (reptype) regs.wordregs[regcx]--; //putreg16(regcx, (regs.wordregs[regcx]) - 1);
                                totalexec++; loopcount++;
                                timing();
                                if (!reptype) break;
                                ip = firstip;
                                //if (loopcount>=execloops) { ip = firstip; return; }
                                //if (ifl && (i8259.irr & (~i8259.imr))) { ip = firstip; break; } //save IP and stop loop execution if an interrupt is requested
                        //}
                        break;
                        case 0xAC: //AC LODSB
                        //while(1) {
                                if (reptype && (regs.wordregs[regcx]==0)) break;
                                regs.byteregs[regal] = getmem8(useseg, regs.wordregs[regsi]);
                                if (df) regs.wordregs[regsi] = regs.wordregs[regsi] - 1; else regs.wordregs[regsi] = regs.wordregs[regsi] + 1;
                                if (reptype) regs.wordregs[regcx]--; //putreg16(regcx, (regs.wordregs[regcx]) - 1);
                                totalexec++; loopcount++;
                                timing();
                                if (!reptype) break;
                                ip = firstip;
                                //if (loopcount>=execloops) { ip = firstip; return; }
                                //if (ifl && (i8259.irr & (~i8259.imr))) { ip = firstip; break; } //save IP and stop loop execution if an interrupt is requested
                        //}
                        break;
                        case 0xAD: //AD LODSW
                        //while(1) {
                                if (reptype && (regs.wordregs[regcx]==0)) break;
                                oper1 = getmem16(useseg, regs.wordregs[regsi]);
                                regs.byteregs[regah] = oper1 >> 8; regs.byteregs[regal] = oper1 & 255;
                                if (df) regs.wordregs[regsi] = regs.wordregs[regsi] - 2; else regs.wordregs[regsi] = regs.wordregs[regsi] + 2;
                                if (reptype) regs.wordregs[regcx]--; //putreg16(regcx, (regs.wordregs[regcx]) - 1);
                                totalexec++; loopcount++;
                                timing();
                                if (!reptype) break;
                                ip = firstip;
                                //if (loopcount>=execloops) { ip = firstip; return; }
                                //if (ifl && (i8259.irr & (~i8259.imr))) { ip = firstip; break; } //save IP and stop loop execution if an interrupt is requested
                        //}
                        break;
                        case 0xAE: //AE SCASB
                        //while(1) {
                                if (reptype && (regs.wordregs[regcx]==0)) break;
                                oper1b = getmem8(segregs[reges], regs.wordregs[regdi]); oper2b = regs.byteregs[regal];
                                flag_sub8(oper1b, oper2b);
                                if (df) regs.wordregs[regdi] = regs.wordregs[regdi] - 1; else regs.wordregs[regdi] = regs.wordregs[regdi] + 1;
                                if (reptype) regs.wordregs[regcx]--; //putreg16(regcx, (regs.wordregs[regcx]) - 1);
                                if ((reptype == 1) && !zf) break;
                                else if ((reptype == 2) && (zf == 1)) break;
                                totalexec++; loopcount++;
                                timing();
                                if (!reptype) break;
                                ip = firstip;
                                //if (loopcount>=execloops) { ip = firstip; return; }
                                //if (ifl && (i8259.irr & (~i8259.imr))) { ip = firstip; break; } //save IP and stop loop execution if an interrupt is requested
                        //}
                        break;
                        case 0xAF: //AF SCASW
                        //while(1) {
                                if (reptype && (regs.wordregs[regcx]==0)) break;
                                oper1 = getmem16(segregs[reges], regs.wordregs[regdi]); oper2 = (regs.wordregs[regax]);
                                flag_sub16(oper1, oper2);
                                if (df) regs.wordregs[regdi] = regs.wordregs[regdi] - 2; else regs.wordregs[regdi] = regs.wordregs[regdi] + 2;
                                if (reptype) regs.wordregs[regcx]--; //putreg16(regcx, (regs.wordregs[regcx]) - 1);
                                if ((reptype == 1) && !zf) break;
                                else if ((reptype == 2) & (zf == 1)) break;
                                totalexec++; loopcount++;
                                timing();
                                if (!reptype) break;
                                ip = firstip;
                                //if (loopcount>=execloops) { ip = firstip; return; }
                                //if (ifl && (i8259.irr & (~i8259.imr))) { ip = firstip; break; } //save IP and stop loop execution if an interrupt is requested
                        //}
                        break;
                        case 0xB0: //B0 MOV regs.byteregs[regal] Ib
                        regs.byteregs[regal] = getmem8(segregs[regcs], ip); StepIP(1);
                        break;
                        case 0xB1: //B1 MOV regs.byteregs[regcl] Ib
                        regs.byteregs[regcl] = getmem8(segregs[regcs], ip); StepIP(1);
                        break;
                        case 0xB2: //B2 MOV regs.byteregs[regdl] Ib
                        regs.byteregs[regdl] = getmem8(segregs[regcs], ip); StepIP(1);
                        break;
                        case 0xB3: //B3 MOV regs.byteregs[regbl] Ib
                        regs.byteregs[regbl] = getmem8(segregs[regcs], ip); StepIP(1);
                        break;
                        case 0xB4: //B4 MOV regs.byteregs[regah] Ib
                        regs.byteregs[regah] = getmem8(segregs[regcs], ip); StepIP(1);
                        break;
                        case 0xB5: //B5 MOV regs.byteregs[regch] Ib
                        regs.byteregs[regch] = getmem8(segregs[regcs], ip); StepIP(1);
                        break;
                        case 0xB6: //B6 MOV regs.byteregs[regdh] Ib
                        regs.byteregs[regdh] = getmem8(segregs[regcs], ip); StepIP(1);
                        break;
                        case 0xB7: //B7 MOV regs.byteregs[regbh] Ib
                        regs.byteregs[regbh] = getmem8(segregs[regcs], ip); StepIP(1);
                        break;
                        case 0xB8: //B8 MOV eAX Iv
                        oper1 = getmem16(segregs[regcs], ip); StepIP(2);
                        regs.byteregs[regah] = oper1 >> 8; regs.byteregs[regal] = oper1 & 255;
                        break;
                        case 0xB9: //B9 MOV eCX Iv
                        oper1 = getmem16(segregs[regcs], ip); StepIP(2);
                        regs.byteregs[regch] = oper1 >> 8; regs.byteregs[regcl] = oper1 & 255;
                        break;
                        case 0xBA: //BA MOV eDX Iv
                        oper1 = getmem16(segregs[regcs], ip); StepIP(2);
                        regs.byteregs[regdh] = oper1 >> 8; regs.byteregs[regdl] = oper1 & 255;
                        break;
                        case 0xBB: //BB MOV eBX Iv
                        oper1 = getmem16(segregs[regcs], ip); StepIP(2);
                        regs.byteregs[regbh] = oper1 >> 8; regs.byteregs[regbl] = oper1 & 255;
                        break;
                        case 0xBC: //BC MOV eSP Iv
                        regs.wordregs[regsp] = getmem16(segregs[regcs], ip); StepIP(2);
                        break;
                        case 0xBD: //BD MOV eBP Iv
                        regs.wordregs[regbp] = getmem16(segregs[regcs], ip); StepIP(2);
                        break;
                        case 0xBE: //BE MOV eSI Iv
                        regs.wordregs[regsi] = getmem16(segregs[regcs], ip); StepIP(2);
                        break;
                        case 0xBF: //BF MOV eDI Iv
                        regs.wordregs[regdi] = getmem16(segregs[regcs], ip); StepIP(2);
                        break;
                        case 0xC0: //C0 GRP2 byte imm8 (80186+)
                        modregrm();
                        oper1b = readrm8(rm);
                        oper2b = getmem8(segregs[regcs], ip); StepIP(1);
                        writerm8(rm, op_grp2_8(oper2b));
                        
                        break;
                        case 0xC1: //C1 GRP2 word imm8 (80186+)
                        modregrm();
                        oper1 = readrm16(rm);
                        oper2 = getmem8(segregs[regcs], ip); StepIP(1);
                        writerm16(rm, op_grp2_16(oper2));
                        
                        break;
                        case 0xC2: //C2 RET Iw
                        oper1 = getmem16(segregs[regcs], ip);
                        ip = pop();
                        regs.wordregs[regsp] = regs.wordregs[regsp] + oper1;
                        
                        break;
                        case 0xC3: //C3 RET
                        ip = pop();
                        break;
                        case 0xC4: //C4 LES Gv Mp
                        modregrm();
                        getea(rm);
                        putreg16(reg, read86(ea) + read86(ea + 1) * 256);
                        segregs[reges] = read86(ea + 2) + read86(ea + 3) * 256;
                        break;
                        case 0xC5: //C5 LDS Gv Mp
                        modregrm();
                        getea(rm);
                        putreg16(reg, read86(ea) + read86(ea + 1) * 256);
                        segregs[regds] = read86(ea + 2) + read86(ea + 3) * 256;
                        break;
                        case 0xC6: //C6 MOV Eb Ib
                        modregrm();
                        writerm8(rm, getmem8(segregs[regcs], ip)); StepIP(1);
                        break;
                        case 0xC7: //C7 MOV Ev Iv
                        modregrm();
                        writerm16(rm, getmem16(segregs[regcs], ip)); StepIP(2);
                        
                        break;
                        case 0xC8: //C8 ENTER (80186+)
                        stacksize = getmem16(segregs[regcs], ip); StepIP(2);
                        nestlev = getmem8(segregs[regcs], ip); StepIP(1);
                        push(regs.wordregs[regbp]);
                        frametemp = regs.wordregs[regsp];
                        if (nestlev) {
                                for (temp16=1; temp16<nestlev; temp16++) {
                                        regs.wordregs[regbp] = regs.wordregs[regbp] - 2;
                                        push(regs.wordregs[regbp]);
                                }
                                push(regs.wordregs[regsp]);
                        }
                        regs.wordregs[regbp] = frametemp;
                        regs.wordregs[regsp] = regs.wordregs[regbp] - stacksize;
                        
                        break;
                        case 0xC9: //C9 LEAVE (80186+)
                        regs.wordregs[regsp] = regs.wordregs[regbp];
                        regs.wordregs[regbp] = pop();
                        
                        break;
                        case 0xCA: //CA RETF Iw
                        oper1 = getmem16(segregs[regcs], ip);
                        ip = pop(); segregs[regcs] = pop();
                        regs.wordregs[regsp] = regs.wordregs[regsp] + oper1;
                        break;
                        case 0xCB: //CB RETF
                        ip = pop();; segregs[regcs] = pop();
                        break;
                        case 0xCC: //CC INT 3
                        intcall86(3);
                        break;
                        case 0xCD: //CD INT Ib
                        oper1 = getmem8(segregs[regcs], ip); StepIP(1);
                        intcall86(oper1);
                        break;
                        case 0xCE: //CE INTO
                        if (of) intcall86(4);
                        break;
                        case 0xCF: //CF IRET
                        ip = pop(); segregs[regcs] = pop();
                        decodeflagsword(pop());
                        //if (net.enabled) net.canrecv = 1;
                        break;
                        case 0xD0: //D0 GRP2 Eb 1
                        modregrm();
                        oper1b = readrm8(rm);
                        writerm8(rm, op_grp2_8(1));
                        break;
                        case 0xD1: //D1 GRP2 Ev 1
                        modregrm();
                        oper1 = readrm16(rm);
                        writerm16(rm, op_grp2_16(1));
                        break;
                        case 0xD2: //D2 GRP2 Eb regs.byteregs[regcl]
                        modregrm();
                        oper1b = readrm8(rm);
                        writerm8(rm, op_grp2_8(regs.byteregs[regcl]));
                        break;
                        case 0xD3: //D3 GRP2 Ev regs.byteregs[regcl]
                        modregrm();
                        oper1 = readrm16(rm);
                        writerm16(rm, op_grp2_16(regs.byteregs[regcl]));
                        break;
                        case 0xD4: //D4 AAM I0
                        oper1 = getmem8(segregs[regcs], ip); StepIP(1);
                        if (!oper1) { intcall86(0); return; } //division by zero
                        regs.byteregs[regah] = (regs.byteregs[regal] / oper1) & 255;
                        regs.byteregs[regal] = (regs.byteregs[regal] % oper1) & 255;
                        flag_szp16 (regs.wordregs[regax]);
                        
                        break;
                        case 0xD5: //D5 AAD I0
                        oper1 = getmem8(segregs[regcs], ip); StepIP(1);
                        regs.byteregs[regal] = (regs.byteregs[regah] * oper1 + regs.byteregs[regal]) & 255;
                        regs.byteregs[regah] = 0;
                        flag_szp16(regs.byteregs[regah] * oper1 + regs.byteregs[regal]);
                        sf = 0;
                        break;
                        case 0xD7: //D7 XLAT
                        regs.byteregs[regal] = read86(useseg * 16 + (regs.wordregs[regbx]) + regs.byteregs[regal]);
                        break;
                        case 0xD8 ... 0xDF: //escape
                        StepIP(1);
                        break;
                        case 0xE0: //E0 LOOPNZ Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        putreg16(regcx, (regs.wordregs[regcx]) - 1);
                        if ((regs.wordregs[regcx]) && !zf) ip = ip + temp16;
                        
                        break;
                        case 0xE1: //E1 LOOPZ Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        putreg16(regcx, (regs.wordregs[regcx]) - 1);
                        if ((regs.wordregs[regcx]) && (zf == 1)) ip = ip + temp16;
                        
                        break;
                        case 0xE2: //E2 LOOP Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        putreg16(regcx, (regs.wordregs[regcx]) - 1);
                        if (regs.wordregs[regcx]) ip = ip + temp16;
                        
                        break;
                        case 0xE3: //E3 JCXZ Jb
                        temp16 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        if (!(regs.wordregs[regcx])) ip = ip + temp16;
                        
                        break;
                        case 0xE4: //E4 IN regs.byteregs[regal] Ib
                        oper1b = getmem8(segregs[regcs], ip);
                        StepIP(1);
                        regs.byteregs[regal] = portin(oper1b);
                        break;
                        case 0xE5: //E5 IN eAX Ib
                        oper1b = getmem8(segregs[regcs], ip);
                        StepIP(1);
                        putreg16(regax, portin(oper1b));
                        break;
                        case 0xE6: //E6 OUT Ib regs.byteregs[regal]
                        oper1b = getmem8(segregs[regcs], ip);
                        StepIP(1);
                        portout16 = 0;
                        portout(oper1b, regs.byteregs[regal]);
                        break;
                        case 0xE7: //E7 OUT Ib eAX
                        oper1b = getmem8(segregs[regcs], ip);
                        StepIP(1);
                        portout16 = 1;
                        portout(oper1b, (regs.wordregs[regax]));
                        
                        break;
                        case 0xE8: //E8 CALL Jv
                        oper1 = getmem16(segregs[regcs], ip); StepIP(2);
                        push(ip);
                        ip = ip + oper1;
                        break;
                        case 0xE9: //E9 JMP Jv
                        oper1 = getmem16(segregs[regcs], ip); StepIP(2);
                        ip = ip + oper1;
                        break;
                        case 0xEA: //EA JMP Ap
                        oper1 = getmem16(segregs[regcs], ip); StepIP(2);
                        oper2 = getmem16(segregs[regcs], ip);
                        ip = oper1; segregs[regcs] = oper2;
                        break;
                        case 0xEB: //EB JMP Jb
                        oper1 = signext(getmem8(segregs[regcs], ip)); StepIP(1);
                        ip = ip + oper1;
                        break;
                        case 0xEC: //EC IN regs.byteregs[regal] regdx
                        oper1 = (regs.wordregs[regdx]);
                        regs.byteregs[regal] = portin(oper1);
                        break;
                        case 0xED: //ED IN eAX regdx
                        oper1 = (regs.wordregs[regdx]);
                        putreg16(regax, portin(oper1));
                        break;
                        case 0xEE: //EE OUT regdx regs.byteregs[regal]
                        oper1 = (regs.wordregs[regdx]);
                        portout16 = 0;
                        portout(oper1, regs.byteregs[regal]);
                        break;
                        case 0xEF: //EF OUT regdx eAX
                        oper1 = (regs.wordregs[regdx]);
                        portout16 = 1;
                        portout(oper1, (regs.wordregs[regax]));
                        break;
                        case 0xF0: //F0 LOCK
                        break;
/*                      case 0xF3: //special fake86: safe to get another network packet
                        RAM[0xE000C] = 1;
                        break;*/
                        case 0xF4: //F4 HLT
                        ip = ip - 1;
                        //running = 0; return;
                        //SDL_WM_SetCaption("Fake86 [halted]", NULL);
                        break;
                        case 0xF5: //F5 CMC
                        if (!cf) cf = 1; else cf = 0;
                        break;
                        case 0xF6: //F6 GRP3a Eb
                        modregrm();
                        oper1b = readrm8(rm);
                        op_grp3_8();
                        if ((reg > 1) && (reg < 4))     writerm8(rm, res8);
                        
                        break;
                        case 0xF7: //F7 GRP3b Ev
                        modregrm();
                        oper1 = readrm16(rm);
                        op_grp3_16();
                        if ((reg > 1) && (reg < 4)) writerm16(rm, res16);
                        break;
                        case 0xF8: //F8 CLC
                        cf = 0;
                        break;
                        case 0xF9: //F9 STC
                        cf = 1;
                        break;
                        case 0xFA: //FA CLI
                        ifl = 0;
                        break;
                        case 0xFB: //FB STI
                        ifl = 1;
                        break;
                        case 0xFC: //FC CLD
                        df = 0;
                        break;
                        case 0xFD: //FD STD
                        df = 1;
                        break;
                        case 0xFE: //FE GRP4 Eb
                        modregrm();
                        oper1b = readrm8(rm); oper2b = 1;
                        if (!reg) {
                                tempcf = cf;
                                res8 = oper1b + oper2b;
                                flag_add8(oper1b, oper2b);
                                cf = tempcf; writerm8(rm, res8);
                                } else {
                                tempcf = cf;
                                res8 = oper1b - oper2b;
                                flag_sub8(oper1b, oper2b);
                                cf = tempcf; writerm8(rm, res8);
                        }
                        break;
                        case 0xFF: //FF GRP5 Ev
                        modregrm();
                        oper1 = readrm16(rm);
                        op_grp5();
                        break;
                        default:
                        //                sprintf(msg, "INVALID OPCODE: %02X @ %04X:%04X\n", opcode, savecs, saveip); print(msg);
                        intcall86(6);
                        break;
                }

                // DEBUG
                if(print_dbg_opcodes && opcodes_file != NULL && loopcount <= 100) {
                                        	fprintf(opcodes_file,
                "0x%02X ip=0x%04hX ax=0x%04hX cx=0x%04hX dx=0x%04hX bx=0x%04hX sp=0x%04hX bp=0x%04hX si=0x%04hX di=0x%04hX "
                "es=0x%04hX cs=0x%04hX ss=0x%04hX ds=0x%04hX "
                "cf=%hhu pf=%hhu af=%hhu zf=%hhu sf=%hhu tf=%hhu if=%hhu df=%hhu of=%hhu iopl=%hhu nt=%hhu "
                "\n",
                opcode, ip, regs.wordregs[regax], regs.wordregs[regcx], regs.wordregs[regdx], regs.wordregs[regbx],
                regs.wordregs[regsp], regs.wordregs[regbp], regs.wordregs[regsi], regs.wordregs[regdi],
                segregs[reges], segregs[regcs], segregs[regss], segregs[regds],
                cf, pf, af, zf, sf, tf, ifl, df, of, iopl, nt);
                                        }

                if(print_dbg_opcodes && asserts_file != NULL && sawNewOpcode && loopcount <= 100) {
                	// cpu;opcode;ax;bx;cx;dx;sp;bp;si;di;es;ds;cs;ss;ip;sp
                	fprintf(asserts_file, "%d;0x%s;"
                			"%d;%d;%d;%d;"	// ax;bx;cx;dx
                			"%d;%d;%d;%d;"	// sp;bp;si;di
                			"%d;%d;%d;%d;"	// es;ds;cs;ss
                			"%d"			// ip
                			"\n",
                			loopcount+1, oplist[opcode],
                			regs.wordregs[regax],regs.wordregs[regbx], regs.wordregs[regcx], regs.wordregs[regdx],
                			regs.wordregs[regsp], regs.wordregs[regbp], regs.wordregs[regsi], regs.wordregs[regdi],
                			segregs[reges], segregs[regds], segregs[regcs], segregs[regss],
                			ip
							);
                }

                //      MutexUnlock(pktmutex);
                if (!running) return;
        }
}
