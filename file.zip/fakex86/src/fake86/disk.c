#include "common.h"

struct struct_drive {
	FILE *diskfile;
	uint32_t filesize;
	uint16_t cyls;
	uint16_t sects;
	uint16_t heads;
	uint8_t inserted;
	char *filename;
} disk[256];
uint8_t sectorbuffer[256][512];

uint8_t insertdisk(uint8_t drivenum, char *filename) {
	if (disk[drivenum].inserted) fclose(disk[drivenum].diskfile);
	else disk[drivenum].inserted = 1;
	disk[drivenum].diskfile = fopen(filename, "r+b");
	if (disk[drivenum].diskfile==NULL) {
		disk[drivenum].inserted = 0;
		sprintf(msg, "ERROR: Unable to open drive image %s\n", filename); print(msg);
		return(1);
	}
	fseek(disk[drivenum].diskfile, 0L, SEEK_END);
	disk[drivenum].filesize = ftell(disk[drivenum].diskfile);
	fseek(disk[drivenum].diskfile, 0L, SEEK_SET);
	if (drivenum >= 0x80) { //it's a hard disk image
		disk[drivenum].sects = 63;
		disk[drivenum].heads = 16;
		disk[drivenum].cyls = disk[drivenum].filesize / (disk[drivenum].sects * disk[drivenum].heads * 512);
		hdcount++;
		} else { //it's a floppy image
		disk[drivenum].cyls = 80; disk[drivenum].sects = 18; disk[drivenum].heads = 2;
		if (disk[drivenum].filesize <= 1228800) disk[drivenum].sects = 15;
		if (disk[drivenum].filesize <= 737280) disk[drivenum].sects = 9;
		if (disk[drivenum].filesize <= 368640) { disk[drivenum].cyls = 40; disk[drivenum].sects = 9; }
	}
	//sprintf(msg, "DEBUG: Disk %02Xh inserted, CHS = %u, %u, %u\n", drivenum, disk[drivenum].cyls, disk[drivenum].heads, disk[drivenum].sects);
	//print(msg);
	return(0);
}

void ejectdisk(uint8_t drivenum) {
	disk[drivenum].inserted = 0;
	fclose(disk[drivenum].diskfile);
}

void readdisk(uint8_t drivenum, uint16_t dstseg, uint16_t dstoff, uint16_t cyl, uint16_t sect, uint16_t head, uint16_t sectcount) {
	uint32_t memdest, cursect, curpos, goodsects, dummy, lba;
	//sprintf(msg, "%02X, %04X:%04X, %u, %u, %u, %u\n", drivenum, dstseg, dstoff, cyl, sect, head, sectcount); print(msg);
	if ((sect==0) || !disk[drivenum].inserted) return;
	lba = ((long)cyl * (long)disk[drivenum].heads + (long)head) * (long)disk[drivenum].sects + (long)sect - 1;
	if ((lba*512)>disk[drivenum].filesize) return;
	fseek(disk[drivenum].diskfile, lba*512, SEEK_SET);
	for (goodsects=0; goodsects<sectcount; goodsects++) {
		dummy = fread(&RAM[((uint32_t)dstseg*16 + (uint32_t)dstoff)], 512, 1, disk[drivenum].diskfile);
		memcpy(&sectorbuffer[regs.byteregs[regdl]][0], &RAM[((uint32_t)dstseg*16 + (uint32_t)dstoff)], 512);
		dstoff += 512;
	}
	cf = 0; regs.byteregs[regah] = 0; regs.byteregs[regal] = sectcount;
}

void writedisk(uint8_t drivenum, uint16_t dstseg, uint16_t dstoff, uint16_t cyl, uint16_t sect, uint16_t head, uint16_t sectcount) {
	uint32_t memdest, cursect, curpos, goodsects, dummy, lba;
	if ((sect==0) || !disk[drivenum].inserted) return;
	lba = ((long)cyl * (long)disk[drivenum].heads + (long)head) * (long)disk[drivenum].sects + (long)sect - 1;
	//sprintf(msg, "[DEBUG] Disk read, LBA sector %u @ %04X:%04X (%05X) - from %u\n", lba, dstseg, dstoff, (uint32_t)dstseg*16 + (uint32_t)dstoff, lba*512); print(msg);
	fseek(disk[drivenum].diskfile, lba*512, SEEK_SET);
	for (goodsects=0; goodsects<sectcount; goodsects++) {
		dummy = fwrite(&RAM[(uint32_t)dstseg*16 + (uint32_t)dstoff], 512, 1, disk[drivenum].diskfile);
		dstoff += 512;
	}
	cf = 0; regs.byteregs[regah] = 0; //regs.byteregs[regal] = sectcount;
}

void diskhandler() {
	static uint8_t lastdiskah[256], lastdiskcf[256];
	//if (regs.byteregs[regdl] & 0x40) regs.byteregs[regdl] = (regs.byteregs[regdl] & 3) | 0x80;
	//if (regs.byteregs[regah]!=2) {
       //sprintf(msg, "Disk handler call AX = %04X\n", regs.wordregs[regax]); print(msg);
	   //sprintf(msg, "  BX = %04X    CX = %04X    DX = %04X\n", regs.wordregs[regbx], regs.wordregs[regcx], regs.wordregs[regdx]); print(msg);
    //}
	switch (regs.byteregs[regah]) {
		case 0: //reset disk system
		regs.byteregs[regah] = 0; cf = 0; //useless function in an emulator. say success and return.
		break;
		case 1: //return last status
		regs.byteregs[regah] = lastdiskah[regs.byteregs[regdl]];
		cf = lastdiskcf[regs.byteregs[regdl]];
		return;
		case 2: //read sector(s) into memory
		if (disk[regs.byteregs[regdl]].inserted) {
		   readdisk(regs.byteregs[regdl], segregs[reges], getreg16(regbx), regs.byteregs[regch] + (regs.byteregs[regcl]/64)*256, regs.byteregs[regcl] & 63, regs.byteregs[regdh], regs.byteregs[regal]);
		   cf = 0; regs.byteregs[regah] = 0;
        } else { cf = 1; regs.byteregs[regah] = 1; }
		break;
		case 3: //write sector(s) from memory
		if (disk[regs.byteregs[regdl]].inserted) {
		   writedisk(regs.byteregs[regdl], segregs[reges], getreg16(regbx), regs.byteregs[regch] + (regs.byteregs[regcl]/64)*256, regs.byteregs[regcl] & 63, regs.byteregs[regdh], regs.byteregs[regal]);
           cf = 0; regs.byteregs[regah] = 0;
        } else { cf = 1; regs.byteregs[regah] = 1; }
		break;
		case 4:
		case 5: //format track
		cf = 0; regs.byteregs[regah] = 0;
		break;
		case 8: //get drive parameters
		if (disk[regs.byteregs[regdl]].inserted) {
			cf = 0; regs.byteregs[regah] = 0;
			regs.byteregs[regch] = disk[regs.byteregs[regdl]].cyls;
			regs.byteregs[regcl] = disk[regs.byteregs[regdl]].sects & 63;
			regs.byteregs[regcl] = regs.byteregs[regcl] + (disk[regs.byteregs[regdl]].cyls/256)*64;
			regs.byteregs[regdh] = disk[regs.byteregs[regdl]].heads - 1;
		    //segregs[reges] = 0; regs.wordregs[regdi] = 0x7C0B; //floppy parameter table
			if (regs.byteregs[regdl]<0x80) {
               regs.byteregs[regbl] = 4; //else regs.byteregs[regbl] = 0;
			   regs.byteregs[regdl] = 2;
           } else regs.byteregs[regdl] = hdcount; 
			} else {
			cf = 1; regs.byteregs[regah] = 0xAA;
		}
		break;
		/*case 0x15: //get disk type
		cf = 0;
		if (regs.byteregs[regdl]<2) regs.byteregs[regah] = 1; 
           else {
                if (disk[regs.byteregs[regdl]].inserted) regs.byteregs[regah] = 3; else { regs.byteregs[regah] = 0; cf = 1; break; }
           }
		putreg16(regcx, ((uint32_t)disk[regs.byteregs[regdl]].sects * (uint32_t)disk[regs.byteregs[regdl]].heads * (uint32_t)disk[regs.byteregs[regdl]].cyls) / 65536);
		putreg16(regdx, ((uint32_t)disk[regs.byteregs[regdl]].sects * (uint32_t)disk[regs.byteregs[regdl]].heads * (uint32_t)disk[regs.byteregs[regdl]].cyls) & 65535);
		break;*/
		default:
		cf = 1;
	}
	lastdiskah[regs.byteregs[regdl]] = regs.byteregs[regah];
	lastdiskcf[regs.byteregs[regdl]] = cf;
	if (regs.byteregs[regdl] & 0x80) RAM[0x474] = regs.byteregs[regah];
}

