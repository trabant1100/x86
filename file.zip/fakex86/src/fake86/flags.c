#include "common.h"

void flag_szp8(uint8_t value) {
   if (!value) zf = 1; else zf = 0;
   if (value & 0x80) sf = 1; else sf = 0;
   pf = parity[value];
}

void flag_szp16(uint16_t value) {
     if (!value) zf = 1; else zf = 0;
     if (value & 0x8000) sf = 1; else sf = 0;
     pf = parity[value & 255];
}

void flag_log8(uint8_t value) {
     flag_szp8(value);
     cf = 0; of = 0;
}

void flag_log16(uint16_t value) {
     flag_szp16(value);
     cf = 0; of = 0;
}

void flag_adc8(uint8_t v1, uint8_t v2, uint8_t v3) {
int16_t dst;
dst = (int16_t)v1 + (int16_t)v2 + (int16_t)v3;
flag_szp8(dst);
if (((dst ^ v1) & (dst ^ v2) & 0x80) == 0x80) of = 1; else of = 0;
if (((dst & 0xFF) < (v1 & 0xFF)) || ((cf & (((v1 & 0xFF) + (v2 & 0xFF) + (v3 & 0xFF)) & 0xFF) == (v1 & 0xFF))))
   cf = 1; else cf = 0;
if (((v1 ^ v2 ^ dst) & 0x10) == 0x10) af = 1; else af = 0;
}

void flag_adc16(uint16_t v1, uint16_t v2, uint16_t v3) {
int32_t dst;
dst = (int32_t)v1 + (int32_t)v2 + (int32_t)v3;
flag_szp16(dst);
if (((dst ^ v1) & (dst ^ v2) & 0x8000) == 0x8000) of = 1; else of = 0;
if (((dst & 0xFFFF) < (v1 & 0xFFFF)) || ((cf & (((v1 & 0xFFFF) + (v2 & 0xFFFF) + (v3 & 0xFFFF)) & 0xFFFF) == (v1 & 0xFFFF))))
   cf = 1; else cf = 0;
if (((v1 ^ v2 ^ dst) & 0x10) == 0x10) af = 1; else af = 0;
}

void flag_add8(uint8_t v1, uint8_t v2) {
int16_t dst;
dst = (int16_t)v1 + (int16_t)v2;
flag_szp8(dst);
if (dst & 0xFF00) cf = 1; else cf = 0;
if (((dst ^ v1) & (dst ^ v2) & 0x80) == 0x80) of = 1; else of = 0;
if (((v1 ^ v2 ^ dst) & 0x10) == 0x10) af = 1; else af = 0;
}

void flag_add16(uint16_t v1, uint16_t v2) {
int32_t dst;
dst = (int32_t)v1 + (int32_t)v2;
flag_szp16(dst);
if (dst & 0xFFFF0000) cf = 1; else cf = 0;
if (((dst ^ v1) & (dst ^ v2) & 0x8000) == 0x8000) of = 1; else of = 0;
if (((v1 ^ v2 ^ dst) & 0x10) == 0x10) af = 1; else af = 0;
}

void flag_sbb8(uint8_t v1, uint8_t v2, uint8_t v3) {
    int16_t dst;
    v2 += v3;
    dst = (int16_t)v1 - (int16_t)v2;
    flag_szp8(dst & 0xFF);
    if (v1 < v2) cf = 1; else cf = 0;
    if ((dst ^ v1) & (v1 ^ v2) & 0x80) of = 1; else of = 0;
    if ((v1 ^ v2 ^ dst) & 0x10) af = 1; else af = 0;
}

void flag_sbb16(uint16_t v1, uint16_t v2, uint16_t v3) {
    int32_t dst;
    v2 += v3;
    dst = (int32_t)v1 - (int32_t)v2;
    flag_szp16(dst & 0xFFFF);
    if (v1 < v2) cf = 1; else cf = 0;
    if ((dst ^ v1) & (v1 ^ v2) & 0x8000) of = 1; else of = 0;
    if ((v1 ^ v2 ^ dst) & 0x10) af = 1; else af = 0;
}

void flag_sub8(uint8_t v1, uint8_t v2) {
    int16_t dst;
    dst = (int16_t)v1 - (int16_t)v2;
    flag_szp8(dst & 0xFF);
    if (v1 < v2) cf = 1; else cf = 0;
    if ((dst ^ v1) & (v1 ^ v2) & 0x80) of = 1; else of = 0;
    if ((v1 ^ v2 ^ dst) & 0x10) af = 1; else af = 0;
}

void flag_sub16(uint16_t v1, uint16_t v2) {
    int32_t dst;
    dst = (int32_t)v1 - (int32_t)v2;
    flag_szp16(dst & 0xFFFF);
    if (v1 < v2) cf = 1; else cf = 0;
    if ((dst ^ v1) & (v1 ^ v2) & 0x8000) of = 1; else of = 0;
    if ((v1 ^ v2 ^ dst) & 0x10) af = 1; else af = 0;
}
