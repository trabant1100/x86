#include "common.h"
#if defined(NETWORKING_ENABLED)

extern uint8_t ethif;
uint8_t enable8139 = 0;
uint8_t reg8139[0x3F];
uint8_t didoneget = 0, pktokay = 1;

/*extern union _bytewordregs_ {
      uint16_t wordregs[8];
      uint8_t byteregs[8];
} regs;
extern uint16_t segregs[4], ip;
extern uint8_t tempcf, oldcf, cf, pf, af, zf, sf, tf, ifl, df, of, mode, reg, rm;

extern char msg[512];
extern void print(char *msg);
extern uint8_t RAM[0xFFFFF];*/

uint8_t dopktrecv = 0;
uint16_t rcvseg, rcvoff, hdrlen, handpkt;

pcap_if_t *alldevs;
pcap_if_t *d;
pcap_t *adhandle;
const u_char *pktdata;
struct pcap_pkthdr *hdr;
int inum;
uint16_t curhandle = 0;
char errbuf[PCAP_ERRBUF_SIZE];
uint8_t maclocal[6] = { 0xDE, 0xAD, 0xBE, 0xEF, 0x13, 0x37 };
struct structmacpkt {
       uint8_t dst[6];
       uint8_t src[6];
} macpkt;

void initpcap() {
    int i=0;
    
    sprintf(msg, "\nObtaining NIC list via libpcap...\n"); print(msg);

    /* Retrieve the device list from the local machine */
    #if defined(_WIN32)
        if (pcap_findalldevs_ex(PCAP_SRC_IF_STRING, NULL /* auth is not needed */, &alldevs, errbuf) == -1)
            {
             sprintf(msg,"Error in pcap_findalldevs_ex: %s\n", errbuf); print(msg);
             exit(1);
        }
    #else

    #endif
    
    /* Print the list */
    for(d= alldevs; d != NULL; d= d->next)
    {
      i++;
      if (ethif==255) {
        sprintf(msg, "%d. %s", i, d->name); print(msg);
        if (d->description) {
            sprintf(msg, " (%s)\n", d->description); print(msg);
        } else {
            sprintf(msg, " (No description available)\n"); print(msg);
        }
      }
    }
    
    if (i == 0)
    {
        sprintf(msg, "\nNo interfaces found! Make sure WinPcap is installed.\n"); print(msg);
        return;
    }
    
    sprintf(msg, "\n"); print(msg);

    if (ethif==255) exit(0);
       else inum = ethif;
    sprintf(msg, "Using network interface %u.\n", ethif); print(msg);
    
    
    if(inum < 1 || inum > i)
    {
        printf("\nInterface number out of range.\n");
        /* Free the device list */
        pcap_freealldevs(alldevs);
        return;
    }
    
    /* Jump to the selected adapter */
    for(d=alldevs, i=0; i< inum-1 ;d=d->next, i++);

    /* Open the device */
    if ( (adhandle= pcap_open(d->name,          // name of the device
                              65536,            // portion of the packet to capture
                                                // 65536 guarantees that the whole packet will be captured on all the link layers
                              PCAP_OPENFLAG_PROMISCUOUS,    // promiscuous mode
                              -1,             // read timeout
                              NULL,             // authentication on the remote machine
                              errbuf            // error buffer
                              ) ) == NULL)
    {
        sprintf(msg,"\nUnable to open the adapter. %s is not supported by WinPcap\n", d->name); print(msg);
        /* Free the device list */
        pcap_freealldevs(alldevs);
        return;
    }

    sprintf(msg, "\nEthernet bridge on %s...\n", d->description); print(msg);
    
    /* At this point, we don't need any more the device list. Free it */
    pcap_freealldevs(alldevs);
    
    /* start the capture */
//    pcap_dispatch(adhandle, 0, packet_handler, NULL);
//      setmac();
//      sprintf(&RAM[0xF0000], "   PKT DRVR\0");
//      RAM[0x60<<4] = 0; RAM[(0x60<<4)+1] = 0;
//      RAM[(0x60<<4)+2] = 0; RAM[(0x60<<4)+3] = 0xF0;
}

void setmac() {
     memcpy(&RAM[0xE0000], &maclocal[0], 6);
}

extern uint8_t savesp;
extern struct netstruct {
       uint8_t enabled;
       uint8_t canrecv;
       uint16_t pktlen;
} net;

void dispatch() {
     int i;
     uint16_t sendlen, oldsp;
     uint32_t pktptr;
     uint8_t checksum;
     pktokay = 0;

    if (pcap_next_ex(adhandle, &hdr, &pktdata)<=0) return;
    if (hdr->len==0) return;

    memcpy(&macpkt, &pktdata[0], 12);
    //here we could insert any filtering based on MAC src and dst values before the packet driver sees the packet
    /*for (i=0; i<6; i++) {
        if (macpkt.dst[i]!=0xFF) break;
    }
    if (i<6) for (i=0; i<6; i++) {
        if (macpkt.dst[i]!=maclocal[i]) return;
    } else return; */

    net.canrecv = 0;
    memcpy(&RAM[0xD0000], &pktdata[0], hdr->len);
    net.pktlen = hdr->len;
    if (verbose) { sprintf(msg, "Received packet of %u bytes.\n", net.pktlen); print(msg); }
    doirq(6); //intcall86(14);
    return;
}

void sendpkt(uint8_t *src, uint16_t len) {
     pcap_sendpacket(adhandle, src, len);
}
#endif
