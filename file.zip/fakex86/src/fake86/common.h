#include <stdint.h>
#include <SDL/SDL.h>
#include "global.h"
#if defined(NETWORKING_ENABLED)
    #define HAVE_REMOTE
    #include "pcap.h"
#endif

extern uint32_t speakercountdown, latch42, pit0latch, pit0command, pit0divisor, doclocktick, timerack;
extern int32_t accum;

extern uint64_t speakerfreq, fullstep, halfstep, curstep, lastspeakertimer, lastssourcetimer, adlibstep[9];
extern uint8_t cursample, curchan;
extern uint64_t lasttimercheck, lastcurstimer, lastspeakertimer;

#if defined(_WIN32)
#include <windows.h>
#else
#include <time.h>
#endif
extern uint64_t curtimer, lasttimer, timerfreq;
extern char *biosfile;
extern int usefullscreen, doaudio;

extern uint8_t byteregtable[8];

extern uint8_t RAM[0x1FFFFF], readonly[0xFFFFF], parity[0xFF];
extern char *oplist[0xFF];
extern char used_opcodes[0xFF];

extern union _bytewordregs_ {
	uint16_t wordregs[8];
	uint8_t byteregs[8];
} regs;

extern uint8_t ethif;
extern FILE *audfile, *vidfile;

extern uint16_t segregs[4];
extern uint8_t opcode, segoverride, reptype, bootdrive, hdcount;
extern uint16_t savecs, saveip, ip, useseg, oldsp;
extern uint8_t tempcf, oldcf, cf, pf, af, zf, sf, tf, ifl, df, of, nt, iopl, mode, reg, rm, msw;
extern uint16_t oper1, oper2, res16, disp16, temp16, dummy, stacksize, frametemp;
extern uint8_t oper1b, oper2b, res8, disp8, temp8, nestlev, addrbyte;
extern uint32_t temp1, temp2, temp3, temp4, temp5, temp32, tempaddr32, ea;
extern int32_t result;
extern uint64_t totalexec, ticksgap, lasttick;
extern uint32_t ips[10];

extern uint16_t portram[0xFFFF];
extern uint8_t VRAM[262144], vidmode, cgabg, blankattr, vidgfxmode, vidcolor;
extern uint16_t cursx, cursy, cols, rows, vgapage, cursorposition, cursorvisible;
extern uint8_t updatedscreen, clocksafe, port3da, port6, portout16;
extern uint16_t VGA_SC[0xFF], VGA_CRTC[0xFF], VGA_ATTR[0xFF], VGA_GC[0xFF];
extern uint32_t x, y, videobase, textbase;
extern uint8_t fontcga[32768];
extern uint32_t palettecga[16], palettevga[256];

extern uint8_t running, debugmode, showcsip, verbose, mouseemu;

extern SDL_Surface *screen;
#if defined(_WIN32)
extern HANDLE screenmutex;
extern HANDLE pktmutex;
#define MutexLock(mutex) WaitForSingleObject(mutex,INFINITE)
#define MutexUnlock(mutex) ReleaseMutex(mutex)
#else
extern pthread_mutex_t screenmutex;
extern pthread_mutex_t pktmutex;
#define MutexLock(mutex) pthread_mutex_lock(&mutex)
#define MutexUnlock(mutex) pthread_mutex_unlock(&mutex)
#endif

extern char msg[512];
extern void print(char *msg);
//extern void logprint(char *msg);

//extern uint16_t signext(uint8_t value);

extern char *bootimage;

extern uint32_t speakercountdown, latch42, pit0latch, pit0command, pit0divisor, doclocktick, timerack;

extern struct structpic {
       uint8_t imr; //mask register
       uint8_t irr; //request register
       uint8_t isr; //service register
       uint8_t icwstep; //used during initialization to keep track of which ICW we're at
       uint8_t icw[5];
       uint8_t intoffset; //interrupt vector offset
       uint8_t priority; //which IRQ has highest priority
       uint8_t autoeoi; //automatic EOI mode
       uint8_t enabled;
} i8259;
