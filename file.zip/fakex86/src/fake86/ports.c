#include "common.h"
uint8_t port3da, recvplip = 1, last37a;
FILE *pliplog;

/*extern uint64_t didticks;

void CALLBACK timercallback(UINT uID, UINT uMsg, DWORD dwUser, DWORD dw1, DWORD dw2) {
     //print("DILDO TIME }:A\n");
     QueryPerformanceCounter(&curtimer);
	if (clocksafe && ((curtimer - lasttimer) >= (timerfreq/(1193180/pit0divisor)))) {
	    doirq(0);
	    didticks++;
		lasttimer = curtimer;
	}
}*/

extern uint64_t timerticks, realticks;
extern float timercomp;
void portout(uint16_t portnum, uint16_t value) {
	uint8_t oldah, oldal;
	portram[portnum] = value;
	/*    if (portnum>0x21) {
		sprintf(msg, "Out to port %X: %X\n", portnum, value);
		print(msg);
	}*/
	switch (portnum) {
		//case 0x20:
		//if (value & 0x20) timerack = 1;
		//break;
		case 0x20 ... 0x21: //i8259
		     out8259(portnum, value);
		     return;
		case 0x40: //pit 0 data port
		switch (pit0command) {
			case 0x36:
			if (pit0latch==0) {
				pit0divisor = (pit0divisor & 0xFF00) + (value & 0xFF);
				pit0latch = 1;
				return;
				} else {
				pit0divisor = (pit0divisor & 0xFF) + (value & 0xFF)*256;
				pit0latch = 0;
				if (pit0divisor==0) pit0divisor = 65536;
				timerticks = timerfreq/(1193180/pit0divisor);
				//timercomp = 1.0;
				//timeKillEvent(mytimer);
				//mytimer = timeSetEvent(1000.0/(1193180.0/pit0divisor), 0, timercallback, NULL, TIME_PERIODIC);
				if (verbose) { sprintf(msg, "Hardware clock tick interval set to %u Hz\n", (uint32_t)(1193180/pit0divisor)); print(msg); }
				return;
			} break;
		} break;
		case 0x42: //speaker countdown
		if (latch42==0) {
			speakercountdown = (speakercountdown & 0xFF00) + value;
			latch42 = 1;
			} else {
			speakercountdown = (speakercountdown & 0xFF) + value*256;
			latch42 = 0;
		} break;
		case 0x43: //pit 0 command port
		pit0command = value;
		switch (pit0command) {
			case 0x36: //reprogram pit 0 divisor
			pit0latch = 0; break;
			case 0xB6:
			latch42 = 0; break;
		} break;
		
		/*case 0x1F0 ... 0x1F7: case 0x3F0: //ATA controller
		sprintf(msg, "ATA bus write 0x%03X: %02X\n", portnum, value); print(msg);
		ataout(portnum, value);
		break;*/
		
		case 0x378: //LPT1 (disney sound source emulation)
		     putssourcebyte(value);
		     break;
        case 0x37A: //same...
             if ((value & 4) && !(last37a & 4)) putssourcebyte(portram[0x378]);
             last37a = value;
             break;

		case 0x388 ... 0x389: //adlib
		     outadlib(portnum, value);
		     break;

		case 0x3B8: //hercules support
		if (((value & 2) == 2) && (vidmode != 127)) {
			oldah = regs.byteregs[regah]; oldal = regs.byteregs[regal];
			regs.byteregs[regah] = 0; regs.byteregs[regal] = 127;
			vidinterrupt();
			regs.byteregs[regah] = oldah; regs.byteregs[regal] = oldal;
		}
		if (value & 0x80) videobase = 0xB8000; else videobase = 0xB0000;
		break;
		case 0x3C0 ... 0x3D9: //VGA
		outVGA(portnum, value);
		break;
	}
}

uint16_t portin(uint16_t portnum) {
	uint8_t tval, derngs;
	//return(0);
	/*if (portnum>0x21) {
		sprintf(msg, "In from port %X\n", portnum);
		print(msg);
	}*/
	switch (portnum) {
		//case 0x00 ... 0x5F: return(0);
		case 0x20 ... 0x21: //i8259
		     return(in8259(portnum));
		case 0x40:
		if (pit0latch==0) {
			pit0latch = 1;
			return(pit0divisor & 0xFF);
			} else {
			pit0latch = 0;
			return((pit0divisor >> 8) & 0xFF);
		} break;
		case 0x43:
		return(pit0command);
		case 0x60:
		case 0x63:
		tval = portram[portnum];
		if (portnum==0x63) portram[portnum] = 0;
		return(tval);
		
		/*case 0x1F0 ... 0x1F7: case 0x3F0: //ATA controller
		//sprintf(msg, "ATA bus read 0x%03X\n", portnum); print(msg);
		return(atain(portnum));
		break;*/
		case 0x22C:
		return(0);
		
		case 0x379: //LPT1 status (disney sound source emulation)
		     if (ssourcefull()) return(0x40);
                else return(0);

		case 0x388: //adlib status
             return(inadlib(portnum));
		
		case 0x3C0 ... 0x3D9: //VGA
		switch (portnum) {
			case 0x3C1: return(VGA_ATTR[portram[0x3C0]]);
			case 0x3C5: return(VGA_SC[portram[0x3C4]]);
			case 0x3D5: return(VGA_CRTC[portram[0x3D4]]);
			default: return(portram[portnum]);
		}
		break;
		case 0x3DA:
		/*if (port3da==0) port3da = 1;
		else if (port3da==1) port3da = 8;
		else if (port3da==8) port3da = 11;
		else port3da = 0;*/
		port3da = (rand() % 2) * 8 + (rand() % 2); //gotta do something about this nastyness
		return(port3da);
		
		case 0x3F9 ... 0x3FE:
		switch (portnum) {
			case 0x3FC: return(1);
			case 0x3FD: return(97);
			case 0x3FE: return(16);
			default: return(0);
		}
		break;
		default:
		return(0x80);
	}
}

